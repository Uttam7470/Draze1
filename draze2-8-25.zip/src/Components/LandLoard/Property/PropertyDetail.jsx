import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  FaRupeeSign,
  FaLock,
  FaCalendarAlt,
  FaBolt,
  FaMapMarkerAlt,
  FaHome,
  FaCouch,
  FaBed,
  FaBath,
  FaListUl,
} from "react-icons/fa";

const amenityIcons = {
  Wifi: "📶",
  Parking: "🚗",
  Water: "🚿",
  PowerBackup: "🔌",
  AC: "❄️",
  Heater: "🔥",
  TV: "📺",
  Bed: "🛎",
  Table: "🪑",
  Laundry: "🪺",
  Kitchen: "🍽",
  Fridge: "🫪",
  Security: "🚱",
  Elevator: "🚗",
  Balcony: "🌇",
  Gym: "🏋",
  CCTV: "📹",
  Garden: "🌳",
  Housekeeping: "🩹",
};

const PLACEHOLDER_IMAGE = "https://via.placeholder.com/220";

const PropertyDetail = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);

  useEffect(() => {
    const properties = JSON.parse(localStorage.getItem("properties")) || [];
    const found = properties.find((p) => String(p.id) === String(id));
    setProperty(found || null);
  }, [id]);

  if (!property) {
    return (
      <div className="py-10 text-center">
        <h4 className="text-red-500 text-lg font-semibold">Property not found</h4>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <h2 className="text-2xl sm:text-3xl font-bold text-center text-blue-700 mb-8">
        {property.title || "Untitled Property"}
      </h2>

      {/* Images */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {property.images?.length > 0 ? (
          property.images.map((img, idx) => (
            <div key={idx} className="rounded-lg overflow-hidden shadow-sm">
              <img
                src={img}
                alt={`Property image ${idx + 1}`}
                className="w-full h-56 object-cover"
                onError={(e) => {
                  e.target.src = PLACEHOLDER_IMAGE;
                }}
              />
            </div>
          ))
        ) : (
          <div className="col-span-full text-center text-gray-500">
            No images available
          </div>
        )}
      </div>

      {/* About Section */}
      <section className="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-6">
        <h3 className="text-xl font-semibold mb-4">About This Property</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-4 gap-x-6 text-gray-700">
          <div><FaHome className="inline mr-2 text-blue-500" /> <strong>Type:</strong> {property.type || "N/A"}</div>
          <div><FaCouch className="inline mr-2 text-blue-500" /> <strong>Furnishing:</strong> {property.furnishing || "N/A"}</div>
          <div><FaBed className="inline mr-2 text-blue-500" /> <strong>Bedrooms:</strong> {property.bedrooms || "N/A"}</div>
          <div><FaBath className="inline mr-2 text-blue-500" /> <strong>Bathrooms:</strong> {property.bathrooms || "N/A"}</div>
          <div className="sm:col-span-2">
            <FaMapMarkerAlt className="inline mr-2 text-blue-500" />
            <strong>Location:</strong>{" "}
            {[property.address, property.city, property.state, property.pincode]
              .filter(Boolean)
              .join(", ") || "N/A"}
          </div>
        </div>
      </section>

      {/* Renting Terms */}
      <section className="bg-gray-50 rounded-lg shadow-md p-4 sm:p-6 mb-6">
        <h3 className="text-xl font-semibold mb-4">Renting Terms</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-y-4 gap-x-6 text-gray-800">
          <div><FaRupeeSign className="inline mr-2 text-green-600" /> <strong>Rent:</strong> ₹{property.rent || "N/A"}</div>
          <div><FaRupeeSign className="inline mr-2 text-yellow-500" /> <strong>Deposit:</strong> ₹{property.deposit || "N/A"}</div>
          <div><FaLock className="inline mr-2 text-red-500" /> <strong>Lock-in Period:</strong> {property.lockin || "N/A"}</div>
          <div><FaCalendarAlt className="inline mr-2 text-indigo-500" /> <strong>Notice Period:</strong> {property.notice || "N/A"}</div>
          <div><FaBolt className="inline mr-2 text-yellow-400" /> <strong>Electricity Unit:</strong> {property.electricity || "N/A"}</div>
        </div>
      </section>

      {/* Amenities */}
      {property.amenities?.length > 0 && (
        <section className="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-6">
          <h3 className="text-xl font-semibold mb-4">Amenities</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {property.amenities.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 border rounded-lg px-3 py-2 bg-gray-50 shadow-sm">
                <span className="text-lg">{amenityIcons[item] || "✅"}</span>
                <span className="text-sm">{item}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Rules */}
      {property.rules?.length > 0 && (
        <section className="bg-gray-50 rounded-lg shadow-md p-4 sm:p-6 mb-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center text-gray-800">
            <FaListUl className="mr-2" /> Rules
          </h3>
          <ul className="list-disc ml-5 text-gray-700 space-y-1">
            {property.rules.map((rule, idx) => (
              <li key={idx}>{rule}</li>
            ))}
          </ul>
        </section>
      )}

      {/* Description */}
      <section className="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-6">
        <h3 className="text-xl font-semibold mb-3">Description</h3>
        <p className="text-gray-600">{property.description || "No description provided."}</p>
      </section>

      {/* Edit Button */}
      <div className="text-center mt-8">
        <Link
          to={`/add-property?id=${property.id}`}
          className="inline-block px-6 py-2 bg-blue-600 text-white text-sm rounded-full hover:bg-blue-700 transition"
        >
          Edit Property
        </Link>
      </div>
    </div>
  );
};

export default PropertyDetail;
