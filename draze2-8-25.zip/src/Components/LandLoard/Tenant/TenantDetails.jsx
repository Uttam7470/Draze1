// import React, { useState } from "react";
// import { useLocation, useNavigate } from "react-router-dom";
// import {
//   FaUser, FaHome, FaMoneyCheckAlt, FaEdit, FaArrowLeft,
//   FaPhone, FaBed, FaBuilding, FaCalendar, FaLock,
//   FaFileContract, FaMoneyBillWave, FaBolt,
// } from "react-icons/fa";

// const TenantDetails = () => {
//   const { state: tenant } = useLocation();
//   const navigate = useNavigate();
//   const [expandedSections, setExpandedSections] = useState({
//     tenantInfo: true,
//     propertyDetails: true,
//     rentalTerms: true,
//   });

//   const toggleSection = (section) => {
//     setExpandedSections((prev) => ({
//       ...prev,
//       [section]: !prev[section],
//     }));
//   };

//   if (!tenant) {
//     return (
//       <div className="max-w-4xl mx-auto py-10 text-center">
//         <p className="text-gray-500 text-lg animate-fadeIn">
//           No tenant details found.
//         </p>
//         <button
//           className="mt-4 border border-blue-600 text-blue-600 px-4 py-2 rounded hover:bg-blue-50 transition"
//           onClick={() => navigate("/tenant-list")}
//         >
//           <FaArrowLeft className="inline-block mr-2" /> Back to List
//         </button>
//       </div>
//     );
//   }

//   return (
//     <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-3">
//         <h2 className="text-2xl font-bold text-blue-600">Tenant Details</h2>
//         <button
//           className="border border-blue-600 text-blue-600 px-4 py-2 rounded hover:bg-blue-50 transition"
//           onClick={() => navigate("/tenant-list")}
//         >
//           <FaArrowLeft className="inline-block mr-2" /> Back to List
//         </button>
//       </div>

//       <div className="bg-white shadow-xl rounded-2xl p-6">
//         {/* Sections */}
//         <Section
//           title="Tenant Information"
//           icon={<FaUser />}
//           expanded={expandedSections.tenantInfo}
//           onToggle={() => toggleSection("tenantInfo")}
//         >
//           <Info label="Name" value={tenant.name} icon={<FaUser />} />
//           <Info label="Mobile" value={tenant.mobile} icon={<FaPhone />} />
//           <Info label="Stay Type" value={tenant.stayType} icon={<FaUser />} />
//           <Info label="Tenant Type" value={tenant.TenantType} icon={<FaUser />} />
//           <Info label="Booked By" value={tenant.bookedby} icon={<FaUser />} />
//           <Info label="Referred By" value={tenant.referredby} icon={<FaUser />} />
//         </Section>

//         <Section
//           title="Property Details"
//           icon={<FaHome />}
//           expanded={expandedSections.propertyDetails}
//           onToggle={() => toggleSection("propertyDetails")}
//         >
//           <Info label="Property Type" value={tenant.PropertyType} icon={<FaBuilding />} />
//           <Info label="Room Number" value={tenant.room} icon={<FaHome />} />
//           <Info label="Bed Number" value={tenant.bed} icon={<FaBed />} />
//           <Info label="Other Details" value={tenant.otherdetails} icon={<FaFileContract />} />
//         </Section>

//         <Section
//           title="Rental Terms"
//           icon={<FaMoneyCheckAlt />}
//           expanded={expandedSections.rentalTerms}
//           onToggle={() => toggleSection("rentalTerms")}
//         >
//           <Info label="Move In Date" value={tenant.moveInDate} icon={<FaCalendar />} />
//           <Info label="Move Out Date" value={tenant.moveOutDate} icon={<FaCalendar />} />
//           <Info label="Lock-in Period" value={`${tenant.lockInPeriod || 0} Months`} icon={<FaLock />} />
//           <Info label="Notice Period" value={`${tenant.noticePeriod || 30} Days`} icon={<FaLock />} />
//           <Info label="Agreement Period" value={tenant.agreementPeriod} icon={<FaFileContract />} />
//           <Info label="Fixed Rent" value={`₹${tenant.fixedRent || 0}`} icon={<FaMoneyBillWave />} />
//           <Info label="Rental Frequency" value={tenant.rentalFrequency} icon={<FaMoneyCheckAlt />} />
//           <Info label="Add Rent On" value={tenant.addRentOn ? `Day ${tenant.addRentOn}` : "N/A"} icon={<FaMoneyCheckAlt />} />
//           <Info label="Security Deposit" value={`₹${tenant.securityDeposit || 0}`} icon={<FaMoneyBillWave />} />
//           <Info label="Electricity Meter" value={tenant.electricityMeter} icon={<FaBolt />} />
//         </Section>

//         {/* Edit Button */}
//         <div className="text-end mt-6">
//           <button
//             onClick={() => navigate("/tenant-form", { state: tenant })}
//             className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded shadow transition"
//           >
//             <FaEdit className="inline-block mr-2" /> Edit Tenant
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// const Section = ({ title, icon, children, expanded, onToggle }) => (
//   <div className="mb-6">
//     <div
//       className="flex items-center gap-2 cursor-pointer mb-3 text-blue-600 hover:text-blue-800 transition"
//       onClick={onToggle}
//     >
//       <span>{icon}</span>
//       <h4 className="text-lg font-semibold">{title}</h4>
//     </div>
//     {expanded && <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{children}</div>}
//   </div>
// );

// const Info = ({ label, value, icon }) => (
//   <div className="flex items-start gap-3 p-3 border rounded-lg hover:bg-gray-50">
//     <div className="text-blue-500 mt-1">{icon}</div>
//     <div>
//       <p className="text-sm text-gray-500 font-medium">{label}</p>
//       <p className="text-gray-800 font-semibold break-words">{value || "N/A"}</p>
//     </div>
//   </div>
// );

// export default TenantDetails;






import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  FaUser, FaHome, FaMoneyCheckAlt, FaEdit, FaArrowLeft,
  FaPhone, FaBed, FaBuilding, FaCalendar, FaLock,
  FaFileContract, FaMoneyBillWave, FaBolt,
} from "react-icons/fa";

const TenantDetails = () => {
  const { state: tenant } = useLocation();
  const navigate = useNavigate();
  const [expandedSections, setExpandedSections] = useState({
    tenantInfo: true,
    propertyDetails: true,
    rentalTerms: true,
  });

  const toggleSection = (section) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  if (!tenant) {
    return (
      <div className="max-w-4xl mx-auto py-10 text-center">
        <p className="text-gray-500 text-lg">No tenant details found.</p>
        <button
          className="mt-4 border border-blue-600 text-blue-600 px-4 py-2 rounded hover:bg-blue-50 transition"
          onClick={() => navigate("/tenant-list")}
        >
          <FaArrowLeft className="inline-block mr-2" /> Back to List
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-3">
        <h2 className="text-2xl font-bold text-blue-600">Tenant Details</h2>
        <button
          className="border border-blue-600 text-blue-600 px-4 py-2 rounded hover:bg-blue-50 transition"
          onClick={() => navigate("/tenant-list")}
        >
          <FaArrowLeft className="inline-block mr-2" /> Back to List
        </button>
      </div>

      <div className="bg-white shadow-xl rounded-2xl p-6">
        {/* Sections */}
        <Section
          title="Tenant Information"
          icon={<FaUser />}
          expanded={expandedSections.tenantInfo}
          onToggle={() => toggleSection("tenantInfo")}
        >
          <Info label="Name" value={tenant.name} icon={<FaUser />} />
          <Info label="Mobile" value={tenant.mobile} icon={<FaPhone />} />
          <Info label="Stay Type" value={tenant.stayType} icon={<FaUser />} />
          <Info label="Tenant Type" value={tenant.tenantType} icon={<FaUser />} />
          <Info label="Booked By" value={tenant.bookedBy} icon={<FaUser />} />
          <Info label="Referred By" value={tenant.referredBy} icon={<FaUser />} />
        </Section>

        <Section
          title="Property Details"
          icon={<FaHome />}
          expanded={expandedSections.propertyDetails}
          onToggle={() => toggleSection("propertyDetails")}
        >
          <Info label="Property Type" value={tenant.propertyType} icon={<FaBuilding />} />
          <Info label="Room Number" value={tenant.room} icon={<FaHome />} />
          <Info label="Bed Number" value={tenant.bed} icon={<FaBed />} />
          <Info label="Other Details" value={tenant.otherDetails} icon={<FaFileContract />} />
        </Section>

        <Section
          title="Rental Terms"
          icon={<FaMoneyCheckAlt />}
          expanded={expandedSections.rentalTerms}
          onToggle={() => toggleSection("rentalTerms")}
        >
          <Info label="Move In Date" value={tenant.moveInDate} icon={<FaCalendar />} />
          <Info label="Move Out Date" value={tenant.moveOutDate} icon={<FaCalendar />} />
          <Info label="Lock-in Period" value={`${tenant.lockInPeriod || 0} Months`} icon={<FaLock />} />
          <Info label="Notice Period" value={`${tenant.noticePeriod || 30} Days`} icon={<FaLock />} />
          <Info label="Agreement Period" value={tenant.agreementPeriod} icon={<FaFileContract />} />
          <Info label="Fixed Rent" value={`₹${tenant.fixedRent || 0}`} icon={<FaMoneyBillWave />} />
          <Info label="Rental Frequency" value={tenant.rentalFrequency} icon={<FaMoneyCheckAlt />} />
          <Info label="Add Rent On" value={tenant.addRentOn ? `Day ${tenant.addRentOn}` : "N/A"} icon={<FaMoneyCheckAlt />} />
          <Info label="Security Deposit" value={`₹${tenant.securityDeposit || 0}`} icon={<FaMoneyBillWave />} />
          <Info label="Electricity Meter" value={tenant.electricityMeter} icon={<FaBolt />} />
        </Section>

        {/* Edit Button */}
        <div className="text-end mt-6">
          <button
            onClick={() => navigate("/tenant-form", { state: tenant })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded shadow transition"
          >
            <FaEdit className="inline-block mr-2" /> Edit Tenant
          </button>
        </div>
      </div>
    </div>
  );
};

const Section = ({ title, icon, children, expanded, onToggle }) => (
  <div className="mb-6">
    <div
      className="flex items-center gap-2 cursor-pointer mb-3 text-blue-600 hover:text-blue-800 transition"
      onClick={onToggle}
    >
      <span>{icon}</span>
      <h4 className="text-lg font-semibold">{title}</h4>
    </div>
    {expanded && <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{children}</div>}
  </div>
);

const Info = ({ label, value, icon }) => (
  <div className="flex items-start gap-3 p-3 border rounded-lg hover:bg-gray-50">
    <div className="text-blue-500 mt-1">{icon}</div>
    <div>
      <p className="text-sm text-gray-500 font-medium">{label}</p>
      <p className="text-gray-800 font-semibold break-words">{value || "N/A"}</p>
    </div>
  </div>
);

export default TenantDetails;
