// import React, { useState, useEffect } from "react";
// import { useLocation, useNavigate, Link } from "react-router-dom";
// import {
//   FaUser,
//   FaHome,
//   FaMoneyCheckAlt,
//   FaArrowLeft,
//   FaPhone,
//   FaBed,
//   FaCalendar,
//   FaLock,
//   FaFileContract,
//   FaMoneyBillWave,
//   FaBolt,
//   FaMapMarkerAlt,
//   FaCouch,
// } from "react-icons/fa";
// import { v4 as uuidv4 } from "uuid";

// const TenantForm = () => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const [successMessage, setSuccessMessage] = useState("");
//   const [formData, setFormData] = useState({
//     id: uuidv4(),
//     name: "",
//     phone: "",
//     property: "",
//     rent: "",
//     address: "",
//     roomType: "",
//     furnishing: "",
//     noticePeriod: "",
//     lockInPeriod: "",
//     agreementDuration: "",
//     deposit: "",
//     electricityCharges: "",
//     startDate: "",
//   });

//   useEffect(() => {
//     if (location.state?.propertyTitle) {
//       setFormData((prev) => ({ ...prev, property: location.state.propertyTitle }));
//     }
//   }, [location.state]);

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const tenants = JSON.parse(localStorage.getItem("tenants")) || [];
//     tenants.push(formData);
//     localStorage.setItem("tenants", JSON.stringify(tenants));
//     setSuccessMessage("Tenant added successfully!");
//     setTimeout(() => navigate("/tenants"), 2000);
//   };

//   return (
//     <div className="max-w-5xl mx-auto px-4 py-6">
//       {/* Back Button */}
//       <button
//         onClick={() => navigate(-1)}
//         className="mb-4 inline-flex items-center bg-gray-100 text-gray-800 px-4 py-2 rounded hover:bg-gray-200 transition"
//       >
//         <FaArrowLeft className="mr-2" /> Go Back
//       </button>

//       {/* Card */}
//       <div className="bg-white shadow-lg rounded-lg overflow-hidden">
//         <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4">
//           <h3 className="text-xl font-semibold flex items-center">
//             <FaUser className="mr-2" /> Tenant Details Form
//           </h3>
//         </div>

//         {/* Form */}
//         <form onSubmit={handleSubmit} className="p-6 space-y-4">
//           {successMessage && (
//             <div className="p-3 bg-green-100 text-green-800 rounded text-center">
//               {successMessage}
//             </div>
//           )}

//           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//             <Input label="Tenant Name" icon={<FaUser />} name="name" value={formData.name} onChange={handleChange} required />
//             <Input label="Phone Number" icon={<FaPhone />} name="phone" value={formData.phone} onChange={handleChange} required />
//             <Input label="Property Name" icon={<FaHome />} name="property" value={formData.property} onChange={handleChange} required />
//             <Input label="Monthly Rent (₹)" icon={<FaMoneyCheckAlt />} name="rent" type="number" value={formData.rent} onChange={handleChange} required />

//             {/* Address */}
//             <div className="md:col-span-2">
//               <Label icon={<FaMapMarkerAlt />} text="Address" />
//               <textarea
//                 name="address"
//                 value={formData.address}
//                 onChange={handleChange}
//                 rows={3}
//                 placeholder="Enter full address"
//                 className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//               />
//             </div>

//             <Select label="Room Type" icon={<FaBed />} name="roomType" value={formData.roomType} onChange={handleChange} options={["Single", "Double", "Triple"]} />
//             <Select label="Furnishing Status" icon={<FaCouch />} name="furnishing" value={formData.furnishing} onChange={handleChange} options={["Furnished", "Semi-Furnished", "Unfurnished"]} />
//             <Input label="Notice Period (in days)" icon={<FaCalendar />} name="noticePeriod" type="number" value={formData.noticePeriod} onChange={handleChange} />
//             <Input label="Lock-in Period (months)" icon={<FaLock />} name="lockInPeriod" type="number" value={formData.lockInPeriod} onChange={handleChange} />
//             <Input label="Agreement Duration (months)" icon={<FaFileContract />} name="agreementDuration" type="number" value={formData.agreementDuration} onChange={handleChange} />
//             <Input label="Security Deposit (₹)" icon={<FaMoneyBillWave />} name="deposit" type="number" value={formData.deposit} onChange={handleChange} />
//             <Input label="Electricity Charges (₹)" icon={<FaBolt />} name="electricityCharges" type="number" value={formData.electricityCharges} onChange={handleChange} />
//             <Input label="Rent Start Date" icon={<FaCalendar />} name="startDate" type="date" value={formData.startDate} onChange={handleChange} />
//           </div>

//           {/* Buttons */}
//           <div className="flex flex-col md:flex-row justify-end md:space-x-4 gap-3 mt-6">
//             <button
//               type="submit"
//               className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
//             >
//               Save Tenant
//             </button>
//             <Link to="/tenant-list">
//               <button
//                 type="button"
//                 className="bg-gray-200 text-gray-800 px-6 py-2 rounded hover:bg-gray-300 transition"
//               >
//                 View Tenants
//               </button>
//             </Link>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// const Input = ({ label, icon, ...props }) => (
//   <div>
//     <Label icon={icon} text={label} />
//     <input
//       {...props}
//       className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//     />
//   </div>
// );

// const Select = ({ label, icon, options, ...props }) => (
//   <div>
//     <Label icon={icon} text={label} />
//     <select
//       {...props}
//       className="w-full p-3 border rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
//     >
//       <option value="">Select {label.toLowerCase()}</option>
//       {options.map((opt) => (
//         <option key={opt} value={opt}>
//           {opt}
//         </option>
//       ))}
//     </select>
//   </div>
// );

// const Label = ({ icon, text }) => (
//   <label className="block mb-1 font-medium flex items-center text-gray-700">
//     <span className="mr-2">{icon}</span>
//     {text}
//   </label>
// );

// export default TenantForm;




import React, { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import {
  FaUser, FaHome, FaMoneyCheckAlt, FaArrowLeft, FaPhone, FaBed, FaCalendar,
  FaLock, FaFileContract, FaMoneyBillWave, FaBolt, FaMapMarkerAlt, FaCouch
} from "react-icons/fa";
import { v4 as uuidv4 } from "uuid";

const TenantForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const editingTenant = location.state;
  const isEdit = Boolean(editingTenant);
  const [successMessage, setSuccessMessage] = useState("");

  const [formData, setFormData] = useState({
    id: uuidv4(),
    name: "",
    phone: "",
    property: "",
    rent: "",
    address: "",
    roomType: "",
    furnishing: "",
    noticePeriod: "",
    lockInPeriod: "",
    agreementDuration: "",
    deposit: "",
    electricityCharges: "",
    startDate: "",
  });

  useEffect(() => {
    if (editingTenant) {
      setFormData({ ...editingTenant });
    } else if (location.state?.propertyTitle) {
      setFormData((prev) => ({ ...prev, property: location.state.propertyTitle }));
    }
  }, [editingTenant, location.state]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const tenants = JSON.parse(localStorage.getItem("tenants")) || [];

    if (isEdit) {
      const updatedTenants = tenants.map((t) => (t.id === formData.id ? formData : t));
      localStorage.setItem("tenants", JSON.stringify(updatedTenants));
      setSuccessMessage("Tenant updated successfully!");
    } else {
      tenants.push(formData);
      localStorage.setItem("tenants", JSON.stringify(tenants));
      setSuccessMessage("Tenant added successfully!");
    }

    setTimeout(() => navigate("/landlord/tenant-list"), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <button
        onClick={() => navigate(-1)}
        className="mb-4 inline-flex items-center bg-gray-100 text-gray-800 px-4 py-2 rounded hover:bg-gray-200 transition"
      >
        <FaArrowLeft className="mr-2" /> Go Back
      </button>

      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-4">
          <h3 className="text-xl font-semibold flex items-center">
            <FaUser className="mr-2" /> {isEdit ? "Edit Tenant" : "Tenant Details Form"}
          </h3>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {successMessage && (
            <div className="p-3 bg-green-100 text-green-800 rounded text-center">
              {successMessage}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Tenant Name" icon={<FaUser />} name="name" value={formData.name} onChange={handleChange} required />
            <Input label="Phone Number" icon={<FaPhone />} name="phone" value={formData.phone} onChange={handleChange} required />
            <Input label="Property Name" icon={<FaHome />} name="property" value={formData.property} onChange={handleChange} required />
            <Input label="Monthly Rent (₹)" icon={<FaMoneyCheckAlt />} name="rent" type="number" value={formData.rent} onChange={handleChange} required />

            <div className="md:col-span-2">
              <Label icon={<FaMapMarkerAlt />} text="Address" />
              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                rows={3}
                placeholder="Enter full address"
                className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <Select label="Room Type" icon={<FaBed />} name="roomType" value={formData.roomType} onChange={handleChange} options={["Single", "Double", "Triple"]} />
            <Select label="Furnishing Status" icon={<FaCouch />} name="furnishing" value={formData.furnishing} onChange={handleChange} options={["Furnished", "Semi-Furnished", "Unfurnished"]} />
            <Input label="Notice Period (days)" icon={<FaCalendar />} name="noticePeriod" type="number" value={formData.noticePeriod} onChange={handleChange} />
            <Input label="Lock-in Period (months)" icon={<FaLock />} name="lockInPeriod" type="number" value={formData.lockInPeriod} onChange={handleChange} />
            <Input label="Agreement Duration (months)" icon={<FaFileContract />} name="agreementDuration" type="number" value={formData.agreementDuration} onChange={handleChange} />
            <Input label="Security Deposit (₹)" icon={<FaMoneyBillWave />} name="deposit" type="number" value={formData.deposit} onChange={handleChange} />
            <Input label="Electricity Charges (₹)" icon={<FaBolt />} name="electricityCharges" type="number" value={formData.electricityCharges} onChange={handleChange} />
            <Input label="Rent Start Date" icon={<FaCalendar />} name="startDate" type="date" value={formData.startDate} onChange={handleChange} />
          </div>

          <div className="flex flex-col md:flex-row justify-end md:space-x-4 gap-3 mt-6">
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition"
            >
              {isEdit ? "Update Tenant" : "Save Tenant"}
            </button>
            <Link to="/landlord/tenant-list">
              <button
                type="button"
                className="bg-gray-200 text-gray-800 px-6 py-2 rounded hover:bg-gray-300 transition"
              >
                View Tenants
              </button>
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

const Input = ({ label, icon, ...props }) => (
  <div>
    <Label icon={icon} text={label} />
    <input
      {...props}
      className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  </div>
);

const Select = ({ label, icon, options, ...props }) => (
  <div>
    <Label icon={icon} text={label} />
    <select
      {...props}
      className="w-full p-3 border rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <option value="">Select {label.toLowerCase()}</option>
      {options.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  </div>
);

const Label = ({ icon, text }) => (
  <label className="block mb-1 font-medium flex items-center text-gray-700">
    <span className="mr-2">{icon}</span>
    {text}
  </label>
);

export default TenantForm;
