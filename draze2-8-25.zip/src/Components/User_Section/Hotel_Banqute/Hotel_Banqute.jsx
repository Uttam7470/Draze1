
  


// import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import AOS from "aos";
// import "aos/dist/aos.css";

// const hotels = [
//   {
//     id: 1,
//     name: "Regal Palace Hotel",
//     image: "https://r1imghtlak.mmtcdn.com/47bd2b486f3411e798fc0a4cef95d023.jpg",
//     city: "Mumbai",
//     location: "Andheri West",
//     rating: 4.5,
//     pricePerNight: 4200,
//     banquet: {
//       name: "Crystal Banquet",
//       capacity: 200,
//       pricePerEvent: 80000
//     },
//     amenities: ["Free Wi-Fi", "Pool", "Banquet Hall", "Parking", "Multi-cuisine Restaurant"],
//     status: "available",
//     contact: "+91-9000000001",
//     description: "Elegant hotel with premium rooms and versatile banquet facility for events."
//   },
//   {
//     id: 2,
//     name: "Urban Link Hotel",
//     image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKe9c2rBhT-tpCJtNHmEx6X52syXmBCqyn3DFqrhaCNsGPS3OzJl9pZ0IDhqrSRgv1PXD5&s",
//     city: "Delhi",
//     location: "Dwarka",
//     rating: 4.0,
//     pricePerNight: 3100,
//     banquet: {
//       name: "Emerald Hall",
//       capacity: 100,
//       pricePerEvent: 40000
//     },
//     amenities: ["AC Rooms", "Banquet Hall", "Room Service", "Lift"],
//     status: "available",
//     contact: "+91-9000000002",
//     description: "Affordable hotel offering a mid-size banquet for celebrations."
//   },

//   {
//     id: 4,
//     name: "Blue Horizon Inn",
//     image: "https://media.gettyimages.com/id/2157918418/photo/the-modern-interior-of-the-event-hall-ready-for-a-wedding-reception.jpg?s=612x612&w=0&k=20&c=JLjpzl1VY_GMy-8bXrEds7_Bb0F1rbYdwaieEhTWzYs=",
//     city: "Kolkata",
//     location: "Salt Lake",
//     rating: 4.2,
//     pricePerNight: 3550,
//     banquet: {
//       name: "Opal Ballroom",
//       capacity: 150,
//       pricePerEvent: 55000
//     },
//     amenities: ["Banquet Hall", "Bar", "Gym", "Wi-Fi"],
//     status: "available",
//     contact: "+91-9000000004",
//     description: "Comfortable inn boasting a large modern banquet space."
//   },
//   {
//     id: 5,
//     name: "Maple Leaf Suites",
//     image: "https://media.gettyimages.com/id/1133167868/photo/decorated-wedding-hall-with-stage.jpg?s=612x612&w=0&k=20&c=DexYtEw29w1CGrVI7QIyRGg8jUBWlq8rttkrrGqfQmk=",
//     city: "Bangalore",
//     location: "Whitefield",
//     rating: 4.4,
//     pricePerNight: 5400,
//     banquet: {
//       name: "Maple Banquet",
//       capacity: 80,
//       pricePerEvent: 38000
//     },
//     amenities: ["Spa", "Banquet Hall", "Cafe", "Valet Parking"],
//     status: "available",
//     contact: "+91-9000000005",
//     description: "Upscale suites with versatile banquet and recreational amenities."
//   }
// ];

// function Hotel_Banqute() {
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     AOS.init({ duration: 800, once: true });
//     window.scrollTo({ top: 0, behavior: "smooth" });

//     const timer = setTimeout(() => setLoading(false), 3000);
//     return () => clearTimeout(timer);
//   }, []);

//   if (loading) {
//     return (
//       <div className="flex justify-center items-center min-h-screen bg-white">
//         <div className="w-16 h-16 border-4 border-blue-500 border-dashed rounded-full animate-spin"></div>
//       </div>
//     );
//   }

//   return (
//     <div className="bg-gray-100 py-10 min-h-screen">
//       <h2
//         className="text-3xl font-bold text-center mb-8 text-gray-800"
//         data-aos="fade-down"
//       >
//         Hotels with Banquet Halls
//       </h2>

//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-4 sm:px-10">
//         {hotels.map((hotel, index) => (
//           <Link
//             to={`/hotel/${hotel.id}`}
//             state={{ hotel }}
//             key={hotel.id}
//             data-aos="fade-up"
//             data-aos-delay={index * 100}
//           >
//             <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 cursor-pointer">
//               <img
//                 src={hotel.image}
//                 alt={hotel.name}
//                 className="w-full h-48 object-cover rounded-t-lg"
//               />
//               <div className="p-4">
//                 <h3 className="text-xl font-semibold text-blue-700">{hotel.name}</h3>
//                 <p className="text-sm text-gray-600">
//                   {hotel.location}, {hotel.city}
//                 </p>
//                 <p className="mt-2 text-gray-700">
//                   {hotel.description.substring(0, 50)}...
//                 </p>
//               </div>
//             </div>
//           </Link>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default Hotel_Banqute;




import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";


const hotels = [
  {
    id: 1,
    name: "Regal Palace Hotel",
    image: "https://r1imghtlak.mmtcdn.com/47bd2b486f3411e798fc0a4cef95d023.jpg",
    city: "Mumbai",
    location: "Andheri West",
    rating: 4.5,
    pricePerNight: 4200,
    banquet: {
      name: "Crystal Banquet",
      capacity: 200,
      pricePerEvent: 80000
    },
    amenities: ["Free Wi-Fi", "Pool", "Banquet Hall", "Parking", "Multi-cuisine Restaurant"],
    status: "available",
    contact: "+91-9000000001",
    description: "Elegant hotel with premium rooms and versatile banquet facility for events."
  },
  {
    id: 2,
    name: "Urban Link Hotel",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKe9c2rBhT-tpCJtNHmEx6X52syXmBCqyn3DFqrhaCNsGPS3OzJl9pZ0IDhqrSRgv1PXD5&s",
    city: "Delhi",
    location: "Dwarka",
    rating: 4.0,
    pricePerNight: 3100,
    banquet: {
      name: "Emerald Hall",
      capacity: 100,
      pricePerEvent: 40000
    },
    amenities: ["AC Rooms", "Banquet Hall", "Room Service", "Lift"],
    status: "available",
    contact: "+91-9000000002",
    description: "Affordable hotel offering a mid-size banquet for celebrations."
  },
    {
    id: 3,
    name: "Sunshine Residency",
    image: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQBDgMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAADBQIEBgEABwj/xABOEAACAQMCAgUFCgcPBQEBAAABAgMABBEFIRIxBhMiQVEUYXGBkRUjJDJCkqGx0dIzUlRicoLBBxYlNDVTc4OEk5SisuHwREVjdMLxZP/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwQABf/EACsRAAICAQMEAQQCAgMAAAAAAAABAhEDEiExBBNBUSIyQlJxM2EU8IGRof/aAAwDAQACEQMRAD8AmlxNEvBKOOP8VvtpPqnR2y1DMll8Hmxuh+KfsrSazrcGpwoDZxRTDm6bZ9IpMJMb14T+L+LN6VmLuIdQ0abDq0e/pVqv2fSJOH3zKMOY7q08rx3EPU3Uayp4EZNILronHNMWtLpURuaOM4qqyQmqmBpoOmv2hXJcA+ipDXrP+doEfQ2XH8ch+YftqQ6Fyn/rIvmH7a6sXs4sDXLRuUy+up+7NudhMPVQk6DXB5XUfzDRv3jXAxm7iHpBpX2wnBqkHdMnraiDVI+6VfUaiOhUy7+W2/rzRF6HXGMreWx9Z+yluHsOx0agj/LHtrvla/jr7akvRG+AytzbEfpH7K6eiup5GJrXH6Tfdrvj7DsBe6H4y/OFAk1CNE4mcY8M1Zl6KaoeUlof12+7VGfohqp3DWh9Dt92iowfkBE6rD/Or7ag+qW+DmZcemq0nRHVfG2/vG+yqz9EtTzgm1H9YfsqqhD2Bsb6Tdx3FxOkbhsAHY+n/amWMmkGhaNf6dfNLN1XVMhVgr5Pdju81aJRvvUsiinsNE5w4Fcxind/e2MukQW8NnwXCbvLnPF5qTNvkAc6DSTCmKdQu0hvlVmA4E8e88/2V1NQjAADr7aW6l0e1G+1Ke4jEPAzYXikGcAYH1VFOiGqHBxb/P8A9qpoh7Et2N/dCPvZfbUlvFY5GD66XJ0P1bO3k/8AeH7tXYOiOrgjtW4/rD92klCPsZMsrcseQ29NFW6P4o+dQx0T1cH8Laj+tb7tSXonqLHtTWee/wB+P3anpj7Dt7CG+UfKX20M6nF8qRPnCvP0QvW53NiP64/dqu/Qy8/K7L+8P3a5Rj7O29lj3SiA4utTf84UN9UhA3lT5wqu/Qu74Nri0/vT92q0/Qy8I/jVmfMJD92mUMfsDZdOq2+PwyH9YVH3Ut+6WP5wpU3Qu83xPabf+Q/dob9DL7G01n/eH7tUWPF+QLY1n1eCKMsZUIHPtZpFfdI55H+C8IQd8g5+qpL0PvusAkltVTO7cZ2/y0+sdJ07T04RGtxLjDSSDPsFMo4ce/Iu72C9f4mprMPGsVbaxcwnhZhMvg/P201ttct5MCQmI+D8vbSywSiFSNIJB41IPkUrjulZQQ4IPIirEVwp+UKi00OXxgjuoiKCwB5HwFVo5A2ykE+ajK+G54peA0Mr/R5bOCO4do2ik5FGBwfPS8rz5H1V15LxgeqeEoPxiaq9fMx/CWrE+DnnXSaDR15USVYnG7glezzouB5qn7n6uSPgW55ZR+Xm2rx0/WBz08+x/u0dqACPADvj5td6rv7jRBZasv8A0Ht4/u1wWmrA7WOfn/dof8nbEOVeEqdb1WBxAZxjuqRg1Yf9vPtP2V0W+o5D+5nbI3OfD1eeqJC7BMD/AIKvWGlzXsU0sAGIRl8kCl/V6oB/Jw+fRYjqiKQtmRxc8NTJIDIshUnvz31FhjnmvMuq4204Y8OKhFNX7tO9j0jQUzqSKzEKTtU6EIdX5DTD8+prBq5/7Z/nrtIbDwW73EqRxrl2OF9NFv7CWwuGguF4ZBzFAjTVlORp3CR38fKuTLq0rFnseJvFn3p6VC3uCbnmh9crSGPfiHMYqXk+qk/xFV8/ET+yomz1YMStpH6e3v8ARSNDHioPIUGZxGQvBxE8gBR/I9YO/kiex/sqJstYPK0T5j/ZSuvYbQEDPxkArjcKqSRsBnlRvc3Wm5Wg/upPsqXuRr7DaxYj/wBaT7KCSfkNoroVZFdV5jIBFGgh6+VIwAGY4Gar3tvqtiVF7FFBxDKiWN029dBSW8zkeTbeBam0o6x5q+mtpcqxSyxSOV4iI24gKXll81A6yVl9+YFvzc4zUWfh+Nt6a5pXscv7Dl8DYgUEy70pvNZhiJWM9c47k3A9J5UludWu5myZerHcqVaGCUhHNIqPCoHZG9BORz38M91XHXHPagulbtRGgUVy8BzE7ITzxyNXItcnXAdVP53KqToKlYL8Ni9NdJRato7dMZrr8nZKqVOc5UjfzVch6TTKdoc55jNXYrdNtqcaRZrNcIkcYZmOAMVhlmxfiWjBlvQdYhutJu3m06UzRqSJUccK7E4IPmU+ygmWzvCOFgkh5Z7LCtBaabaWiXnHl5mSWNhnsgEAnb0gfTSnV9HSQBZIw2FG5G/KsffhKVGmWNwSZCDWdZ0bhSBfK4NwI2Gcejwq9F061YLg6YoyO/irKRLqNjczR2speCIqBDL2s5GcA8x9NNrO+W6zlWSUfGRhuKtKEeUR2fKGydNdU/IFx+tR16daiAPgI9pperxqDxycP6u31USC1Fy3vV3aZPc1xGp9hNLXo6orehinTnUDzsR9NEHTe+/I/rqsNDuP56z/AMZF9tcOlzJ8a4s/8XD96ueOZ2rH+KLv7977ush9NSHTbUPyNfa1KuoCtwteWQP/ALcP3qMLTAHw2y/xsP3qKUvDC3BfaMP366j+SR+01E9NdSz/ABWP2mqfkpx/HbH/ABsP3qBMiREB7+x3/wD7IftotT9nJwf2jT9+uo/kkR9Javfv01I/9HD7WpatsHXIv7DH/uw/er3k6L8bUNPH9uhH/wBVyhk9guH4l9umeqd1nCfW1Bfplq35FD7Wqrwwrz1PTh/b4T/9VHhtz/3TTj/boftrtEjrh+IdummsD4tlDj11E9NdYxvZQ/TQOrts/wAq6aP7dD9te6i2Of4X0sem/i+2u0yO+P4km6Za0dxZw+w0CTphrudrSH2H7aL5PbY/ljS/8fF9tU7owwyBI7y3uWP5NMJMenFDQ/KDaJnphr45Wlv80/bUD016TkdUtrAhbbjEe6+jeuCKV4HnRHMSY4mHJc8s0uur2C3QGaYA+Gdz6qeMfSFdEnEs8puLyZ5Zj8ZmOTVqzvrGzaSS+g65Cu2X4QD41lbzXZZOLySIgDbjbf2ClV4buSdlmcuwO+eXsq8MD8iSyD2916HiItk4tzhidhSa4vZblj10hbPcNh/vQUs5Hbttk+amCaJciPj6vaqpQgwqMpK6BRG1EWJOMnuA5VUlSMt2FwKsPbPGSrKRih9VVVJeCTi1yS1GzvNKm6i9hZfAkbN6D31WyHGR7K+q6gkdwjRTxq8bc1blWJ1jo2iB5tPk4ANzE249RrPj6mE+dmHS0Zt8b+NS08fD4v0qErTHHGgKnvB3o9kpGoxKfEYrRLZMEWm0a+AZIFa3o5Gtqyvjtnv8Kz1lEBgnwp5ZScLL5q8VuzWiEl+fKbpSfjSSA+xabXgEio2d+Fc+ysTJdFdTuE/8j9/orZ8XFEgP4o+qpzx6JWWnPVFCVIVbUbwEbcUXP9Ggav1NjdRMXEfWLwgscZwf96vQD+ErzzSRD/KKQfuhY8p0nIBUTZKnkd60YFqyJMzz4GyTcUfMFT3+NVhpFvcddcJbJiMcUhHMeqlrajJp9rHcWCpDOhyCo29nKqEfSiRWPlCcJbPE0e2fVWmMG7oWS00aVtNsUsVuDHlgxDhUyEHianbabZXCh4o4XQjPETSrTuklgsyyS3HVrnfhbDD0Zoyi31O8f3PvzazndlgZcSeleWfOK7ttcg1s0Vh0S8tci2trdsc9+VMH6A3CxFvJIOyM4BpNpdxPo94JItWvpWC5YGIANnuO29al+mU00fvRuI2/GMasM+YYrrgluI+7exnz0Zt0deuhiEZI4ioBwKpz6LYpMUWJMZPCSm5Hnqd3EbhzINS1RCxJbhVABk/o0C3teouY5zql9cnhOYpYxgexf20lxfkda73JSaLbworvBFwsMjAB2o9vomnPGxMKceBwjhGD6aLqN3Fc2nVRLcRERcBkEQyD4jbz9+T56VGwKvwJrGrSjAwAoG/h8WimvYXrHtj0NW9YLBbWxbGSOLlVmXoDcIP4rbnHPeqmh6nPpIkW3uL2QvjiEoVs4P6NH1rpTPfwG3D3tuCe08TKXI8PibUdUKJvu2KH0e2TYwwE+beqXk9g1yLeOASy/KESZCDz+HroLafFOFKarqYBUs6TzKgA8Mkd49dB92bO0s2tbaIFuIFVibC7ZyW/GJ23z3UdKfDH1SXkaS6XYS3fUwxxFD8UyYGNu+lk9xZacHSFY1OclY9yfXSa51G6nB4j1aH5CbCq9rp8l31jxckG/EafTS3CrbLlxq15PE627CKNjnHFuaow2Ekx43Jbz0PgfrOrGc8seJrV6aI7a04HXLMO3kU05KC2Djx9xmVljEY4QMAHemk2nK7yyFgCdxQNVjWO4yu6Me6iXdy4vJos4AIGKbW3uSlCpUWdPs0iYyPz7qZPOSOe2O6lUd0SOHv7qVavqtysr29vhAo7Uh+MfR4VLtvLI19yOKBc1a6t0yh7UudlHd6apaXpOoa5I62cYYIMktso82fGu9HbCyuVMuqPPwcWOGFuHPnLYNaieXR7KCNI7zUI4z8UC5RQB8yquSx/GPJjk3N2VW6W2r/HQD0NUJNfsZ1YFuEMMY4hSAwL4R+2qtxbxPFK/CuVXI4TmpRw4myjshfxBXZ4HAhZuzwmpaSpfUIQ7kkMO6oSALp8HCAO2R6a7pJ/hOMj8YVqf8bIpfJH0CMYA821XIG3FLY5CKtwvuK8Y2IzE7/w1O+d+Jl+kV9CRj1a57lFfNLhz7qzHvEjbesV9JX8EvoFU6pVpBF2ilAf4Rvv6WH/AErWf/dBOZ9L7vff209tyfdG/wD6eEf5VpJ073vNI80w2/WFHp9sq/3wLLgXSNGYmGQRy51n72PhBlIbq84yBX1K+tI5biGAxRCFg2cRR5B8clDWI6STQwNe6clphEYhWVuXnxWnBkuVISaemxboUIlaXKhmBGM1uNA062We/SaJWc2CvjGwHHy+k1k+iIUeUcXc4Fa3RpSuu3a52bTT9ElL1EnraR2L6QV3cw20jW80NwqY97CjiDYPPINW7WJbzT5LqzhmSKAYk94ZsnPjmuX0avfKJHCdlzlqbaBqawaGYExwPI3EMc+1UO4qKaS3Y3OnRdHWubrQ7qQR9lpRkZPjz2pLp0Bu9QjtorOYF27PWRg5A5jPFtTfUdVC6Hf2o/BCBsKf0TVTS9Qa11SB0wDwNXd6/AqhXk7qFkEsZ7uGxmhjtpgsnGnHxHhO2OLlnG/nqPRye2juxaXmjXM9xKfe8lcLj0Nyq7qusO2kX6Bj2iSaWWV8bfWFkUlW6o4PrrlkXhBcW+Wdkgl1XWpIrDT5rVf5sRqwTGx+Vz2pVc3UUckkSWswmjUxYaMY4+QJ7W3OtFp+rGBlnVvfJG7bePOkt08F1c3zNIYpnmQJhcgsxAz6udFZF6DoEskVzcTt5Yrvwxg9rAwO7lXp7mzs9PteKFHlnIAXGTgY3A/5zqOjvHN0j1G0uWnZncxqynGFT6t6p9IBDp/Si3McJeO3hjZYy53JBPP01qX1V/RNrYb6osVoipLbLGxUHDDGxGxpbf6h7m2HHBGvFLsAdh6fRWostQn1ewN2fg8yMkaiNUOQMcyyk8qzf7ow63VtOQgFTC2Rjn2qnimpT0sdtrjk9o+mN5HBqWo210zXBJjAtyVxnnmtNrbWXkun2cdhc2d5Ky5eZD2wRzz6aw950k1xdMXN9JwRkRouNlXf7Kr6Rruo6jq9qt1MXVXUnJY53HPJNWlilK5koyUZJG0veiYW3kkuLriZRkBVoll0dsLnjublXd2bccWByFPLx+K1lyB8Wg6Wc2pP55+oVh7kq5KtW7EPTOztdP0MvZx9VKzY4wd/bXzyxUeXxSTFpQGDuGOeLG+K+ifugufcZP6SsFpYA1GP1/6TW7pW+02yWXeSQ7XpBpflCyJaogGMKq53zR9T6SWuo20MD2LcMRJDBe0fTWXtIndpGRc8J7hTJLeVgDwNv4gUJ48adjwt8BSapzgLby4GNjVls1WuceTy+g0sOR5FSY/AIh+ea9pG+pRfpCpGJpbFSvCBHlzk8xXdKi6vUrXJB6wK+3gc1ql9DM33o2a5zV2BTkVVhAJq/FtivGNaMXcEHW5x+c31ivpncB3AV8zuVI1udvF2+sV9LOeE4Pmq3V/aLHYWW7/Db4j8qiH+RKTdPTi80nzyj/UKa2+FvLxmYBfK0z6kSsz+6FfgT2JtpUZ4ssRzwRyp+njqypCzlpVn0Atm4jYbgBq+e9JIz7oXzshOXbmKQXuoXWoSCa7mMjb8JKgcOfVU9NguLm8FtEkjySKcL41qh0jx72RWdPYb9F4cm54WDdsFsd3mrSWWItcuCSADp5GSwHy+VI9G6G6jeTXEc0cduyOcddvxE8sYzWl0nopplpIBfXDpcsABC+I8792M5HrH07DJh1ybsZZIxW4s1rW7QXyhVkPBlWOxB9G+9XNES/u7ZUt9OuuEOT1jqEXmT3kZ9Va2Cws7MvPa6dYE88xD31j4b/bR+KAvBDctFFJIh95dO0c+GDgfSfPQXTRoR9R6RmbvTdXmt7mJdPkLSwEKBIpySCMc9zQtRFzpojvbu1dIImMJYMDliBy8RWteG2jht5rxSUjcL1MLl8knAZjzOe8Zx40s6QW0dzFJbXJRGcqxEZGExyAzy2wTS5MEMcbYceZzlSMdddIYZbaWJY5ffCe4U0toL28EWo29sDAyMF4pVU8/rrkmgac8XABw43JU8/Oc1odC6qCCOFeCSC1iIZZVBHCTuT44FQw9ub0o0ZW4RtCbyC+S3RiluFRvwhuVCnz59ePVSO4nubG+g8ss5FFzOhiZHVwwyM44Sc19GugtvCr28bT2zFSgjHbUs2fHHDuMDFcuWEVx79NbNAkRyCMvnv7PL1itf+NFIyf5L8nzHRZ4h0ovJeJVQzzdonxJ50HpG8cvSUvFIHHUw4KnI2FfSDDZ6iI7hbKC7VtuuaMRld9+fa8eVK9T6G6XLO9z5YYJOrCqFYcO3fg7mj22pMos8Gil0c4vcybIxmUHPspH0+wNa07HdCf9VObbQrqaLrNF1KSSFT2usUxAsPDPP01mOkQv7q9gklSSZoMo7KmQmG5HH/7UMeGUMm5TXGStMq3drNeaS0VunHJxg4yBtv41R6MW9wb1bhV96VwrEsNjkd3OnmkSN1bBFyMb4NHhkVbSSYKFVZyxGNx2qos8oxcKHeCMpKV8G2uj8Fm9FB0ls2p/TP1CqUut2EtrIBcKCU5MMZNH0maI2xAkTPHyz5hWDS9JzFH7oLfwOn6dYTTm/hCL1/6TW6/dBXGjIT3vtWB03J1CH9b/AEmvQ6b+JkZ/Wi/pAwk/jxA02C7Us0o9qYBQSWA3NNreKVUbr3RyWyOEYwPCo5+bNeLgWuaqXH4CX0GrJoEo94k9FPDkk+ChdD4LF+lULCVre5EqgFkOQDRrsfB4f066lq0PVSMVYTx8a8O+BnG9bNtO5le0kN06QXmTiCLHoNHHSG/x2Yoh6j9tKEBxxYJHLOKKtZXCCf0mhWya3LzSOZI0EjNx8eN98bc6aza3fytgzshzyGAKTW5AnJO3Yq5NcQo/vK9oUs1bWw0aoJGZriZmmmJLPlsscHbnQHi0qbUQuptcvFGMhLdR2j527qJp9ve6zcm2tI1dgeJsnAA5bn2Vv+j3RazsbPGqJZz3BbPGVDYHcBmq4qhJSkRz3KFR5MTpumaXN0nsYrJJvJ2VpHjmIbhI5Y83praa9odvqVlwpmO4hVnhYNwZPCcKSByJxTddOtI7xHhSxiUKe11ah8+Y9wqxcxhY28kuYet+SZPig+Jp55E5XEzQhLRUjEad0iTTY+pvmuJbiJijCPhCDBxgeNaSN4tSshJIrPFNGGCnmFP1VeOmaOVLPHZuzHLERLuTzPKp28MCIsUtzAoTIjRAAFTuFDJOLpx2YuPHNWpu0ZPUrO/0sdZpd2YLJFLzIzZZccyu2/oNWIOllncyRQpDcmRiEDuqjc95rQTxpLJ1LTWzWjL76sgB4vADNCm07SrSAzWlvZiSMcSYiQ7+yu7kWvktznimn8HsT0+3t9N6y4ikzLdjPBx5EZB327ueaW3cPlM5kYkjJGc8/PUJLos7vIT1r4JwOQxXY5gccz3bV5/VZXL4o9DBjjFWR8iTHxjVjSglpeZOSjghxjOR3j668ROeUM+B/wCM0CR5IGWWSJ1Cn5QIBrNj1QknRWdSi0XLyCd9XEgu82SwjhhhkPx8k9o+jG1CFnb2k095DHwTOuXOckgfVR9Gm8pLxSS4gUtIqsMbliPsq9dnyWNpbKaMt8tSR8XvxXqrJJ+djz3jXrcws/TC6mtxAlsbd5cKknEQUJ7+VONN0GZwTr1y16B+DU7Ko7z560qtpyoOO6AJHym3HqodrMJHl8uvYpFDYjkjGAFxyPnzVu8kqgqIrp23eR2Cu7gWFk8iLmGGPIjyBsOQrJT9JRcW3UWMc9lLO5KPHMGXjY75GN+dbW4miEXBaX8KoTiRHwQw8BtReHS+AdZLGp5jjxsaOLJGNuW7Oy4skqUHSMj0b6PQQQT+6Ua3N31rK3aIUej00m6TWiaQ7w2xPk86mQI25U53Ge8V9BiZHLm+v45iSeGSLGOHuyKz/TXSbS/tBcxalFxW8bFkG5cHHLz7VGaizZCckzErJavbnLAOBsMV66QtdyFGI37jjuFFgj0uKFiYLuWXHxS4CmqVz0ke1YiDS4YnPJpu0f8AnrqSi5bRLyajvI7qhmGmyJJO7oNwCTgGk2nEi/ix5/qNRu9ev75z5S8fB+KI1A+rP00W0kgWdJWVoyM/FGRy/wCeNa4Y5QhTM8skZytF/S8BpM95FOQextnnSWyDxtKw4SpIOVplHcLw5dsb1hzxeo24pfGijgkjhBJ8AKKmj6ncQOUsbgAjAMi9WvtfArRx3F7o8axXFqYlG3WxnhRvSRTIajbcKvHpdsWIyZLiYvk/889ejj6aL4dnkz6qTfFf7+jDz9Hr14E8omtLYKdzLLnHzQR9NOZ7XSbyO1tVu4Q0SBYjCuM9x7RyDyrTXFnqWrWwS5tIIbc79iFIl9p3pVPoWn6bbO9rJZG7wSqxkuwPpqyglsScpyVq7/6X/ouutFMemi2trkM7SdZ1ZU5x6QPrpNFplyLuKK4hnCswBKp3emnCv0juNs28bZ2cgYx4cOP204fUre0cC5nRJwAcY8fCleGDV8AjnyJqKeow9wggv5oQpRUbA4iM4yaFJKiZwvGefPl6zt9FbHqNM1ZmWRg9yoPEVHCwGfNzFcg6NWlsWcFZWzlS4yajLFJK0rNC6qF6ZbMU9D4mmnu5DGQCi8JweeT3+ytSkBQFxkkKcb1UktJLeMK7yxiYeJGcd2RVeOFYJCYWuA3DjIdsfXWGeff5KjYser6WNPJuJu0Dn01OaA8IRgewoK70pnVpe1O0rMd95CaEYBJG0bo7RsO0sjFgfTSd+Ie1IdRxdUHdAeWOdSEO+69mkUVqlsx8nTgz+I3DUpbQznMxaSTu4yTn213fiDtMeyxccjrnePGD4DFShtXBYRoSz4C4BOT6BSAWxMbRGMcDHLJnIJ84ph0eEmnXgOnqijfPcCfRTRzQckmLPHJRdG7t+jdk0ERubeZ5uEcbBsZ9Wdqhe6dbaLH7oW1m7SRfFHblbP6Cgk1RXVda/noVHgVyaL7r60q5Etuf1K9G+m8I87T1BXl6X3skSBY57aQSAuW0i5biTvA7Gx8PRR7fVouk0i2F3bzBRmTe1mixjl2mUVH3c1fh4nS3bB8CK57vaq2/Uw+0/ZR1YPJzjn8IYjQ9OiDIIWweXablVG80K2MMr2iOJ1UlF4ieLzAePh6KrXOsau6jhggJB72P2UGbUdckRlRLaKQDPWFi3D58YFM59Pp2JqHUqSEfV9ZFHIw7bIMk9+1WID1B8mKfHQvjx3A/aPbSW5tuvmdrnhmmJLO7KBkk5NCithFmSMdWeQ4Djbv5V5TzRvY9aOOVbmpjhUICwwGIGaolRdwRT5ySNqUMJ8IvWyFc5x1rAZ9tdNsrARb8C8lJ2OfAd29DvxD22OIIOqKlV7cjcJoOo2nV2NyeH5BqhbQhUZACQG2VWqF3ZwiCSUJHxcJy/e1d/kRboZYXYijbIrkyJIpWRQwPcaX3L3PlUaWzhTwFsHkd8V7y2+h7M9pxDvZK0LDLZpgeRLZnfcq2WXjUJw4OY5ScDzgjcV46GyhiJiM54QBke3vqUWpQzsI+0kjHABHfRJrs2YVsjByO1yBp3LNtHyJox7s7Lpbwoj2crtJ8oM+31ChW91I8jxS8BKjOVxvSu71WWYntcXqwPZUtHPXXMnW8bDgyAq576r25ODcyanFS+J9zjijltzxqHQ81I2PqpFqfRcMpk09sHORA+eH1HurRXk1nAUWx434m4WCgkDz0SI8SZ8KSLcSM0pGDLCE9TeRTpKvJJGJ9mTirWmXOnSM3l8lxbfixxwdYzefI5eseutXeWFvfRGOeNWHce8UhXR5bK6UiTrLYHk1aO+tPogsL1W1q/Ydb20Xs2OkNKRykvJMZ/VGf2UvuejB1e46+6giizv2V6pR9Jb2VpIOyo4Qic9lGNvVRhvgt7O+s8uo9IusUnzsv6E2m9FtO0+QSKCXIwXRu7wyc+buptFDFBgxRqhxni5t9dEAAQEDYkjFcxyB8alLNN+R1igt6M/rxDXyo3EQIwdhyOTSoMnWEs5B/NFMtaJbUpeWFCjf0Cl0bIZDxIox3jnXmz3kz0MfBJQMMMtv8rl9dRiWIKVDNnwYZz6BRVX42QoU9w3NDV1EjLwDg83eaUZUSMYaPtHhC8hnevLwH4gLP3jH7amhGcHCj8XmaGXPGy8IZMkYxQs5LwelVQOsIyfxQ37auaSytdgAtw4PPlQEJwONlA5heZH2UfTJfh/VEqewW5b08PqFktqNAd1B8efmrx+LXicrgHc1F3ChScbc62mTjY5I3Cu/fXc9nHdigyP285HozUuIEHPOicEGOEZGfXQp8mLqV+NIwU78x31LiAXn6q5bMGczsMRwjIz40GFGavADcyIiZy53zjAzUWGAFXtBdiFPL7TUyymaYSEAqw5DfcZrhLoWIGR4nxrFLk1p2qBrwPKCsZUYyCdq6e0WcoWUjcg0WMMVZ8kAdwXeuqXClkHECMjPMZNKFgIAvC4+IoHawDyrlxtaScSE9jbbO2OdWYu0G4mYb9y86HMXFtMyDiBRjg8xXJ7hezMUf5Ti/ompkMBqVk41KDPejAfRTRtiufA16WXwZ4eRfqaAXdm+AMyeaqvSEfBYz+dVzVvwtme7rv2VU1/8AiK/piq4nbhZLJxMz9OOjVy9peySxqWJiK4UgHmPspOKe9FoGnvJUQZPV5+kfbWzM6gzLjXyP0pJDGFLBQDw9wxSLUwI2jkQYJIBxyr1erPIKAwsTnNA1JQY8eNer1SfAyOW5JRAeWKOPi+oV6vVIoSjUNbqD4mo43C92effXK9SnGW1aU+6N2pVTw8OCR5hQLdusZlKqAPAV6vVil9TNkOCE8jQlBHsG5ioi6YSlBHGN8ZAOfrrteoBQZ3MaFk2JPOhPKwGQFzz5V2vUo0eEElObcSfKYHNc0CVn1dyxz73w8u6vV6q4uRJ/SzUKeKIZHdVeduFTgDPPlXq9WtGYXtO4I5c/bVryhxKVAAA9O9er1ccTVzNLwPyz3Uy1CNINJmEYx2cVyvV3g4weqO8OpTNGxHaUY9Qo5mYRjGASp3A89er1Zci4NMF8V+y1AzSJ2mJwufooaTvgjI2IrleqT5LSS3/Z6GV3Uhids95qV0zRdbGGLLwkdr0V6vUPJ0kt/wBGHkHw+1/Rb6qJLcyLqMMAPYZTnNer1exV1+jD7/Z3Vedr/TD6jVXXf4l+uK7Xq7DzAGT7zPjnWj6GbapJj+Yb/Uter1a8/wDGzLDk/9k=",
    city: "Pune",
    location: "Wakad",
    rating: 3.8,
    pricePerNight: 2700,
    banquet: {
      name: "Sunflower Banquet",
      capacity: 60,
      pricePerEvent: 25000
    },
    amenities: ["Free Breakfast", "Parking", "Banquet Hall", "Laundry"],
    status: "available",
    contact: "+91-9000000003",
    description: "Contemporary hotel with intimate banquet facilities for smaller gatherings."
  },

  {
    id: 4,
    name: "Blue Horizon Inn",
    image: "https://media.gettyimages.com/id/2157918418/photo/the-modern-interior-of-the-event-hall-ready-for-a-wedding-reception.jpg?s=612x612&w=0&k=20&c=JLjpzl1VY_GMy-8bXrEds7_Bb0F1rbYdwaieEhTWzYs=",
    city: "Kolkata",
    location: "Salt Lake",
    rating: 4.2,
    pricePerNight: 3550,
    banquet: {
      name: "Opal Ballroom",
      capacity: 150,
      pricePerEvent: 55000
    },
    amenities: ["Banquet Hall", "Bar", "Gym", "Wi-Fi"],
    status: "available",
    contact: "+91-9000000004",
    description: "Comfortable inn boasting a large modern banquet space."
  },
  {
    id: 5,
    name: "Maple Leaf Suites",
    image: "https://media.gettyimages.com/id/1133167868/photo/decorated-wedding-hall-with-stage.jpg?s=612x612&w=0&k=20&c=DexYtEw29w1CGrVI7QIyRGg8jUBWlq8rttkrrGqfQmk=",
    city: "Bangalore",
    location: "Whitefield",
    rating: 4.4,
    pricePerNight: 5400,
    banquet: {
      name: "Maple Banquet",
      capacity: 80,
      pricePerEvent: 38000
    },
    amenities: ["Spa", "Banquet Hall", "Cafe", "Valet Parking"],
    status: "available",
    contact: "+91-9000000005",
    description: "Upscale suites with versatile banquet and recreational amenities."
  }
];

function Hotel_Banqute() {
  const [loading, setLoading] = useState(true);
  const [filteredHotels, setFilteredHotels] = useState(hotels);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [capacityRange, setCapacityRange] = useState("");
  const [priceRange, setPriceRange] = useState("");

  useEffect(() => {
    AOS.init({ duration: 800, once: true });
    window.scrollTo({ top: 0, behavior: "smooth" });

    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const handleFilter = () => {
    let filtered = hotels.filter((hotel) => {
      const matchesSearch =
        hotel.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hotel.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        hotel.location.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCity = selectedCity ? hotel.city === selectedCity : true;

      const matchesCapacity = (() => {
        const capacity = hotel.banquet.capacity;
        if (capacityRange === "0-100") return capacity <= 100;
        if (capacityRange === "101-150") return capacity > 100 && capacity <= 150;
        if (capacityRange === "151+") return capacity > 150;
        return true;
      })();

      const matchesPrice = (() => {
        const price = hotel.banquet.pricePerEvent;
        if (priceRange === "0-40000") return price <= 40000;
        if (priceRange === "40001-70000") return price > 40000 && price <= 70000;
        if (priceRange === "70001+") return price > 70000;
        return true;
      })();

      return matchesSearch && matchesCity && matchesCapacity && matchesPrice;
    });

    setFilteredHotels(filtered);
  };

  const handleReset = () => {
    setSearchTerm("");
    setSelectedCity("");
    setCapacityRange("");
    setPriceRange("");
    setFilteredHotels(hotels);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-white">
        <div className="w-16 h-16 border-4 border-blue-500 border-dashed rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f6f8fa] py-12 px-4">
      <h2 className="text-3xl font-bold text-center mb-6"
        data-aos="fade-down"
      >
        Hotels with Banquet Halls
      </h2>

      {/* ✅ Filter Section */}
      {/* <div
        className="max-w-5xl mx-auto mb-8 
                   bg-white/30 backdrop-blur-md 
                   border border-blue-500/50 shadow-lg
                   rounded-xl p-4
                   flex flex-wrap items-center gap-4 justify-center"
        style={{
          boxShadow: "0 0 12px rgba(59,130,246,0.6)",
          minHeight: "80px",
        }}
      >
        <input
          type="text"
          placeholder="Search by name, city, or location"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border border-blue-500/50 p-2 rounded w-56 bg-white/50 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <select
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.target.value)}
          className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Cities</option>
          <option value="Mumbai">Mumbai</option>
          <option value="Delhi">Delhi</option>
          <option value="Kolkata">Kolkata</option>
          <option value="Bangalore">Bangalore</option>
        </select>

        <select
          value={capacityRange}
          onChange={(e) => setCapacityRange(e.target.value)}
          className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Capacities</option>
          <option value="0-100">Up to 100</option>
          <option value="101-150">101 - 150</option>
          <option value="151+">151+</option>
        </select>

        <select
          value={priceRange}
          onChange={(e) => setPriceRange(e.target.value)}
          className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Prices</option>
          <option value="0-40000">₹0 - ₹40K</option>
          <option value="40001-70000">₹40K - ₹70K</option>
          <option value="70001+">₹70K+</option>
        </select>

        <button
          onClick={handleFilter}
          className="bg-blue-600 text-white px-5 py-2 rounded hover:bg-blue-700 shadow-lg"
        >
          Search
        </button>

        <button
          onClick={handleReset}
          className="bg-gray-400 text-white px-5 py-2 rounded hover:bg-gray-500"
        >
          Reset
        </button>
      </div> */}

      <div
  className="max-w-5xl mx-auto mb-8 
             bg-white/30 backdrop-blur-md 
             border border-blue-500/50 shadow-lg
             rounded-xl p-4
             flex flex-col items-center gap-4"
  style={{
    boxShadow: "0 0 12px rgba(59,130,246,0.6)",
    minHeight: "80px",
  }}
>
  <div className="flex flex-wrap justify-center gap-4 w-full">
    <input
      type="text"
      placeholder="Search by name, city, or location"
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
      className="border border-blue-500/50 p-2 rounded w-56 bg-white/50 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
    />

    <select
      value={selectedCity}
      onChange={(e) => setSelectedCity(e.target.value)}
      className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <option value="">All Cities</option>
      <option value="Mumbai">Mumbai</option>
      <option value="Delhi">Delhi</option>
      <option value="Kolkata">Kolkata</option>
      <option value="Bangalore">Bangalore</option>
    </select>

    <select
      value={capacityRange}
      onChange={(e) => setCapacityRange(e.target.value)}
      className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <option value="">All Capacities</option>
      <option value="0-100">Up to 100</option>
      <option value="101-150">101 - 150</option>
      <option value="151+">151+</option>
    </select>

    <select
      value={priceRange}
      onChange={(e) => setPriceRange(e.target.value)}
      className="border border-blue-500/50 p-2 rounded w-44 bg-white/50 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
      <option value="">All Prices</option>
      <option value="0-40000">₹0 - ₹40K</option>
      <option value="40001-70000">₹40K - ₹70K</option>
      <option value="70001+">₹70K+</option>
    </select>
  </div>

  {/* ✅ Buttons Below */}
  <div className="flex gap-4 mt-2">
    <button
      onClick={handleFilter}
      className="bg-blue-600 text-white px-5 py-2 rounded hover:bg-blue-700 shadow-lg"
    >
      Search
    </button>

    <button
      onClick={handleReset}
      className="bg-gray-400 text-white px-5 py-2 rounded hover:bg-gray-500"
    >
      Reset
    </button>
  </div>
</div>


      {/* ✅ Hotels Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-4 sm:px-10 mt-6">
        {filteredHotels.length === 0 ? (
          <p className="text-center text-gray-500 col-span-full">
            No hotels found.
          </p>
        ) : (
          filteredHotels.map((hotel, index) => (
            <Link
              to={`/hotel/${hotel.id}`}
              state={{ hotel }}
              key={hotel.id}
              data-aos="fade-up"
              data-aos-delay={index * 100}
            >
              <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 cursor-pointer">
                <img
                  src={hotel.image}
                  alt={hotel.name}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-blue-700">
                    {hotel.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {hotel.location}, {hotel.city}
                  </p>
                  <p className="mt-2 text-gray-700">
                    {hotel.description.substring(0, 50)}...
                  </p>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}

export default Hotel_Banqute;
