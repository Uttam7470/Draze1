// import React from 'react';

// function Contact() {
//   return (
//     <div className="min-h-screen px-4 py-16 bg-gradient-to-br from-indigo-200 via-purple-200 to-pink-200 relative overflow-hidden">
//       {/* Decorative Blobs */}
//       <div className="absolute top-0 left-0 w-72 h-72 bg-purple-400 opacity-20 rounded-full blur-3xl -z-10"></div>
//       <div className="absolute bottom-0 right-0 w-72 h-72 bg-pink-400 opacity-20 rounded-full blur-3xl -z-10"></div>

//       <div className="max-w-7xl mx-auto">
//         <h1
//           className="text-4xl font-bold text-center text-[#183c2c] mb-12"
//           data-aos="fade-up"
//         >
//           Contact Us
//         </h1>

//         <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
//           {/* Contact Information */}
//           <div
//             className="backdrop-blur-lg bg-white/30 p-8 rounded-2xl shadow-xl border border-white/20"
//             data-aos="fade-right"
//           >
//             <h2 className="text-2xl font-semibold mb-4 text-[#5C4EFF]">Get in Touch</h2>
//             <p className="text-gray-800 mb-6">
//               We'd love to hear from you! Whether you have a question about listings,
//               features, or anything else, our team is ready to help.
//             </p>

//             <ul className="space-y-4 text-gray-700 font-medium">
//               <li>📍 Address: Draze HQ, 123 Real Estate Street, Mumbai, India</li>
//               <li>📞 Phone: +91 98765 43210</li>
//               <li>📧 Email: contact@draze.com</li>
//               <li>🌐 Website: www.draze.com</li>
//             </ul>
//           </div>

//           {/* Contact Form */}
//           <div
//             className="backdrop-blur-lg bg-white/30 p-8 rounded-2xl shadow-xl border border-white/20"
//             data-aos="fade-left"
//           >
//             <h2 className="text-2xl font-semibold mb-4 text-[#5C4EFF]">Send a Message</h2>
//             <form className="space-y-4">
//               <div>
//                 <label className="block text-gray-800 font-medium">Your Name</label>
//                 <input
//                   type="text"
//                   className="w-full border border-gray-300 rounded px-3 py-2 mt-1 bg-white/60 backdrop-blur-md"
//                   placeholder="John Doe"
//                 />
//               </div>

//               <div>
//                 <label className="block text-gray-800 font-medium">Email</label>
//                 <input
//                   type="email"
//                   className="w-full border border-gray-300 rounded px-3 py-2 mt-1 bg-white/60 backdrop-blur-md"
//                   placeholder="john@example.com"
//                 />
//               </div>

//               <div>
//                 <label className="block text-gray-800 font-medium">Message</label>
//                 <textarea
//                   className="w-full border border-gray-300 rounded px-3 py-2 mt-1 bg-white/60 backdrop-blur-md h-28"
//                   placeholder="Your message..."
//                 ></textarea>
//               </div>

//               <button
//                 type="submit"
//                 className="bg-[#5C4EFF] text-white px-6 py-2 rounded hover:bg-[#443ccc] transition"
//                 data-aos="zoom-in"
//               >
//                 Send Message
//               </button>
//             </form>
//           </div>
//         </div>

//         {/* Google Map */}
//         <div className="mt-16" data-aos="fade-up">
//           <iframe
//             title="Draze Location"
//             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241317.11609959294!2d72.7410995!3d19.0821978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63fb0fb8457%3A0xe51208822e8b8101!2sMumbai!5e0!3m2!1sen!2sin!4v1628252345678"
//             width="100%"
//             height="400"
//             allowFullScreen=""
//             loading="lazy"
//             className="rounded-lg shadow-xl"
//           ></iframe>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Contact;





// import React from 'react';

// function Contact() {
//   return (
//     <div
//       className="min-h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center px-4"
//       style={{
//         backgroundImage:
//           "url('https://images.unsplash.com/photo-1594744803329-c5dc4d0370a4?auto=format&fit=crop&w=1600&q=80')",
//       }}
//     >
//       <div className="bg-black bg-opacity-60 w-full max-w-7xl rounded-xl shadow-lg p-10 grid grid-cols-1 lg:grid-cols-2 gap-10 backdrop-blur-md text-white">
//         {/* Left Section */}
//         <div className="space-y-6">
//           <h2 className="text-4xl font-bold text-white">Why Draze?</h2>
//           <p className="text-lg">Discover your dream property with ease.</p>

//           <div className="space-y-4 text-white">
//             <div>
//               <h4 className="text-xl font-semibold">01. For Agents & Agencies</h4>
//               <p className="text-sm">Convert leads into clients seamlessly.</p>
//             </div>
//             <div>
//               <h4 className="text-xl font-semibold">02. Custom Lead Forms</h4>
//               <p className="text-sm">Track leads without external CRM.</p>
//             </div>
//             <div>
//               <h4 className="text-xl font-semibold">03. Customizable Theme</h4>
//               <p className="text-sm">Tailor your website to your brand.</p>
//             </div>
//           </div>
//         </div>

//         {/* Right Section (Form) */}
//         <div className="bg-white bg-opacity-90 p-8 rounded-lg text-gray-800">
//           <h2 className="text-2xl font-bold mb-1">Property Inquiry</h2>
//           <p className="text-sm mb-4 text-gray-600">Find your perfect property with Draze</p>

//           <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
//             {/* Row 1 */}
//             <div>
//               <label className="block text-sm font-medium">Inquiry Type</label>
//               <select className="w-full mt-1 px-3 py-2 border rounded">
//                 <option>Select Type</option>
//                 <option>Buy</option>
//                 <option>Rent</option>
//               </select>
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Property Type</label>
//               <select className="w-full mt-1 px-3 py-2 border rounded">
//                 <option>Select Property</option>
//                 <option>Flat</option>
//                 <option>Villa</option>
//               </select>
//             </div>

//             {/* Row 2 */}
//             <div>
//               <label className="block text-sm font-medium">Name</label>
//               <input type="text" placeholder="Enter your name" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Mobile</label>
//               <input type="text" placeholder="Enter mobile number" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>

//             {/* Row 3 */}
//             <div>
//               <label className="block text-sm font-medium">Email</label>
//               <input type="email" placeholder="Enter email address" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Location</label>
//               <select className="w-full mt-1 px-3 py-2 border rounded">
//                 <option>Madhya Pradesh</option>
//                 <option>Maharashtra</option>
//               </select>
//             </div>

//             {/* Row 4 */}
//             <div>
//               <label className="block text-sm font-medium">District</label>
//               <select className="w-full mt-1 px-3 py-2 border rounded">
//                 <option>Indore</option>
//                 <option>Bhopal</option>
//               </select>
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Zip</label>
//               <input type="text" placeholder="452001" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>

//             {/* Row 5 */}
//             <div>
//               <label className="block text-sm font-medium">City</label>
//               <input type="text" placeholder="Indore" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Min Size (sq ft)</label>
//               <input type="text" placeholder="Enter min size" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>

//             {/* Row 6 */}
//             <div>
//               <label className="block text-sm font-medium">Max Price</label>
//               <input type="text" placeholder="Enter max price" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>
//             <div>
//               <label className="block text-sm font-medium">Bedrooms</label>
//               <input type="text" placeholder="Number of bedrooms" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>

//             {/* Row 7 */}
//             <div>
//               <label className="block text-sm font-medium">Bathrooms</label>
//               <input type="text" placeholder="Number of bathrooms" className="w-full mt-1 px-3 py-2 border rounded" />
//             </div>
//             <div className="md:col-span-2">
//               <label className="block text-sm font-medium">Message</label>
//               <textarea placeholder="Enter your message" className="w-full mt-1 px-3 py-2 border rounded h-24"></textarea>
//             </div>

//             {/* Agreement */}
//             <div className="md:col-span-2 flex items-center space-x-2">
//               <input type="checkbox" className="w-4 h-4" />
//               <label className="text-sm">"I agree" to complete the form</label>
//             </div>

//             {/* Submit Button */}
//             <div className="md:col-span-2">
//               <button className="bg-emerald-600 text-white px-6 py-2 w-full rounded hover:bg-emerald-700 transition">
//                 Submit Inquiry
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Contact;



import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

function Contact() {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  return (
    <div
      className="min-h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center px-4"
      style={{
        backgroundImage:
          "url('https://media.istockphoto.com/id/2175973016/photo/modern-luxury-home-exterior-at-sunset.webp?a=1&b=1&s=612x612&w=0&k=20&c=B2e-gEujpM7UNHX3uMHqvyh_bHC5sHFYfxf0ldEc6R0=')",
      }}
    >
      <div className="bg-black bg-opacity-50 backdrop-filter text-white p-10 rounded-lg w-full max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        {/* Left: Contact Form */}
        <div data-aos="fade-right">
          <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
          <form className="space-y-4">
            <div>
              <label className="block mb-1 text-sm">Full Name</label>
              <input
                type="text"
                placeholder="Enter your name"
                className="w-full px-4 py-2 rounded text-black"
              />
            </div>
            <div>
              <label className="block mb-1 text-sm">Email</label>
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full px-4 py-2 rounded text-black"
              />
            </div>
            <div>
              <label className="block mb-1 text-sm">Phone</label>
              <input
                type="text"
                placeholder="Enter your phone number"
                className="w-full px-4 py-2 rounded text-black"
              />
            </div>
            <div>
              <label className="block mb-1 text-sm">Message</label>
              <textarea
                placeholder="Type your message..."
                className="w-full px-4 py-2 h-28 rounded text-black"
              ></textarea>
            </div>
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 transition px-6 py-2 rounded text-white text-lg font-medium"
            >
              Send Message
            </button>
          </form>
        </div>

        {/* Right: Content / Info */}
        <div data-aos="fade-left" className="space-y-4">
          <h2 className="text-3xl font-bold">Let’s Connect</h2>
          <p className="text-lg">
            Whether you're looking to rent, buy, or just need advice — we're here to help.
          </p>
          <ul className="space-y-2 text-md">
            <li>
              📍 <strong>Office:</strong> 123 Draze Street, Indore, MP
            </li>
            <li>
              📞 <strong>Phone:</strong> +91 98765 43210
            </li>
            <li>
              📧 <strong>Email:</strong> support@draze.com
            </li>
            <li>
              ⏰ <strong>Hours:</strong> Mon - Sat: 9am – 7pm
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Contact;
