import React from 'react'

function Reel() {
  return (
    <div>Reel</div>
  )
}

export default Reel