


// import React, { useState, useEffect } from "react";
// import { FaBed, FaChair, FaWifi, FaTv, FaTrash, FaEdit } from "react-icons/fa";

// const RoomAdd = () => {
//   const [form, setForm] = useState({
//     roomName: "",
//     floor: "",
//     beds: "",
//     rent: "",
//     image: "",
//     amenities: {
//       bed: false,
//       chair: false,
//       wifi: false,
//       tv: false,
//     },
//   });

//   const [rooms, setRooms] = useState([]);
//   const [editIndex, setEditIndex] = useState(null);

//   useEffect(() => {
//     const saved = JSON.parse(localStorage.getItem("rooms")) || [];
//     setRooms(saved);
//   }, []);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setForm((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleImageChange = (e) => {
//     const file = e.target.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onloadend = () => {
//         setForm((prev) => ({ ...prev, image: reader.result }));
//       };
//       reader.readAsDataURL(file);
//     }
//   };

//   const handleAmenityChange = (amenity) => {
//     setForm((prev) => ({
//       ...prev,
//       amenities: {
//         ...prev.amenities,
//         [amenity]: !prev.amenities[amenity],
//       },
//     }));
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const updatedRooms = [...rooms];

//     if (editIndex !== null) {
//       updatedRooms[editIndex] = form;
//     } else {
//       updatedRooms.push(form);
//     }

//     localStorage.setItem("rooms", JSON.stringify(updatedRooms));
//     setRooms(updatedRooms);
//     setForm({
//       roomName: "",
//       floor: "",
//       beds: "",
//       rent: "",
//       image: "",
//       amenities: {
//         bed: false,
//         chair: false,
//         wifi: false,
//         tv: false,
//       },
//     });
//     setEditIndex(null);
//   };

//   const handleEdit = (index) => {
//     setForm(rooms[index]);
//     setEditIndex(index);
//   };

//   const handleDelete = (index) => {
//     const updated = rooms.filter((_, i) => i !== index);
//     setRooms(updated);
//     localStorage.setItem("rooms", JSON.stringify(updated));
//   };

//   return (
//     <div className="max-w-7xl mx-auto px-4 py-8">
//       <h3 className="text-2xl font-bold text-center mb-6">Add Room</h3>
//       <form onSubmit={handleSubmit} className="space-y-6">
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//           <div>
//             <label className="block font-medium mb-1">Room Name</label>
//             <input
//               type="text"
//               name="roomName"
//               value={form.roomName}
//               onChange={handleChange}
//               placeholder="Enter room name"
//               required
//               className="w-full border rounded p-2"
//             />
//           </div>
//           <div>
//             <label className="block font-medium mb-1">Floor</label>
//             <input
//               type="text"
//               name="floor"
//               value={form.floor}
//               onChange={handleChange}
//               placeholder="e.g. 1st, 2nd"
//               required
//               className="w-full border rounded p-2"
//             />
//           </div>
//           <div>
//             <label className="block font-medium mb-1">Beds</label>
//             <input
//               type="number"
//               name="beds"
//               value={form.beds}
//               onChange={handleChange}
//               placeholder="No. of beds"
//               required
//               className="w-full border rounded p-2"
//             />
//           </div>
//         </div>

//         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//           <div>
//             <label className="block font-medium mb-1">Rent (per bed)</label>
//             <input
//               type="number"
//               name="rent"
//               value={form.rent}
//               onChange={handleChange}
//               placeholder="e.g. 5000"
//               required
//               className="w-full border rounded p-2"
//             />
//           </div>
//           <div>
//             <label className="block font-medium mb-1">Upload Room Image</label>
//             <input
//               type="file"
//               accept="image/*"
//               onChange={handleImageChange}
//               className="w-full"
//             />
//           </div>
//           <div>
//             {form.image && (
//               <img
//                 src={form.image}
//                 alt="Room"
//                 className="w-full h-[180px] object-cover rounded mt-6"
//               />
//             )}
//           </div>
//         </div>

//         <div>
//           <h5 className="font-semibold mb-2">Amenities</h5>
//           <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
//             <label className="flex items-center space-x-2">
//               <input type="checkbox" checked={form.amenities.bed} onChange={() => handleAmenityChange("bed")} />
//               <span className="flex items-center gap-2"><FaBed /> Bed</span>
//             </label>
//             <label className="flex items-center space-x-2">
//               <input type="checkbox" checked={form.amenities.chair} onChange={() => handleAmenityChange("chair")} />
//               <span className="flex items-center gap-2"><FaChair /> Chair</span>
//             </label>
//             <label className="flex items-center space-x-2">
//               <input type="checkbox" checked={form.amenities.wifi} onChange={() => handleAmenityChange("wifi")} />
//               <span className="flex items-center gap-2"><FaWifi /> Wi-Fi</span>
//             </label>
//             <label className="flex items-center space-x-2">
//               <input type="checkbox" checked={form.amenities.tv} onChange={() => handleAmenityChange("tv")} />
//               <span className="flex items-center gap-2"><FaTv /> TV</span>
//             </label>
//           </div>
//         </div>

//         <div className="text-center">
//           <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded">
//             {editIndex !== null ? "Update Room" : "Save Room"}
//           </button>
//         </div>
//       </form>

//       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
//         {rooms.map((room, idx) => (
//           <div key={idx} className="border rounded shadow">
//             {room.image && <img src={room.image} alt="Room" className="w-full h-48 object-cover rounded-t" />}
//             <div className="p-4">
//               <h5 className="font-bold text-lg">{room.roomName}</h5>
//               <p>Floor: {room.floor}</p>
//               <p>Beds: {room.beds}</p>
//               <p>Rent: ₹{room.rent}</p>
//               <div className="flex gap-2 mt-2 text-green-600">
//                 {room.amenities.bed && <FaBed />}
//                 {room.amenities.chair && <FaChair />}
//                 {room.amenities.wifi && <FaWifi />}
//                 {room.amenities.tv && <FaTv />}
//               </div>
//             </div>
//             <div className="flex justify-between items-center border-t p-2">
//               <button onClick={() => handleEdit(idx)} className="text-blue-600">
//                 <FaEdit />
//               </button>
//               <button onClick={() => handleDelete(idx)} className="text-red-600">
//                 <FaTrash />
//               </button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default RoomAdd;





import React, { useState, useEffect } from "react";
import { FaBed, FaChair, FaWifi, FaTv, FaTrash, FaEdit } from "react-icons/fa";

const RoomAdd = () => {
  const [form, setForm] = useState({
    roomName: "",
    floor: "",
    beds: "",
    rent: "",
    image: "",
    amenities: {
      bed: false,
      chair: false,
      wifi: false,
      tv: false,
    },
  });

  const [rooms, setRooms] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("rooms")) || [];
    setRooms(saved);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setForm((prev) => ({ ...prev, image: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAmenityChange = (amenity) => {
    setForm((prev) => ({
      ...prev,
      amenities: {
        ...prev.amenities,
        [amenity]: !prev.amenities[amenity],
      },
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedRooms = [...rooms];

    if (editIndex !== null) {
      updatedRooms[editIndex] = form;
    } else {
      updatedRooms.push(form);
    }

    localStorage.setItem("rooms", JSON.stringify(updatedRooms));
    setRooms(updatedRooms);
    setForm({
      roomName: "",
      floor: "",
      beds: "",
      rent: "",
      image: "",
      amenities: {
        bed: false,
        chair: false,
        wifi: false,
        tv: false,
      },
    });
    setEditIndex(null);
  };

  const handleEdit = (index) => {
    setForm(rooms[index]);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updated = rooms.filter((_, i) => i !== index);
    setRooms(updated);
    localStorage.setItem("rooms", JSON.stringify(updated));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h3 className="text-3xl font-bold text-center mb-8 text-gray-800">
        {editIndex !== null ? "Edit Room" : "Add Room"}
      </h3>

      <form
        onSubmit={handleSubmit}
        className="bg-white shadow rounded-lg p-6 space-y-6"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block font-medium mb-1">Room Name</label>
            <input
              type="text"
              name="roomName"
              value={form.roomName}
              onChange={handleChange}
              placeholder="Enter room name"
              required
              className="w-full border rounded-lg p-2"
            />
          </div>
          <div>
            <label className="block font-medium mb-1">Floor</label>
            <input
              type="text"
              name="floor"
              value={form.floor}
              onChange={handleChange}
              placeholder="e.g. 1st, 2nd"
              required
              className="w-full border rounded-lg p-2"
            />
          </div>
          <div>
            <label className="block font-medium mb-1">Beds</label>
            <input
              type="number"
              name="beds"
              value={form.beds}
              onChange={handleChange}
              placeholder="No. of beds"
              required
              className="w-full border rounded-lg p-2"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block font-medium mb-1">Rent (per bed)</label>
            <input
              type="number"
              name="rent"
              value={form.rent}
              onChange={handleChange}
              placeholder="e.g. 5000"
              required
              className="w-full border rounded-lg p-2"
            />
          </div>
          <div>
            <label className="block font-medium mb-1">Upload Room Image</label>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="w-full"
            />
          </div>
          <div>
            {form.image && (
              <img
                src={form.image}
                alt="Room"
                className="w-full h-40 object-cover rounded-lg mt-4"
              />
            )}
          </div>
        </div>

        <div>
          <h5 className="font-semibold mb-2">Amenities</h5>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { name: "bed", icon: <FaBed />, label: "Bed" },
              { name: "chair", icon: <FaChair />, label: "Chair" },
              { name: "wifi", icon: <FaWifi />, label: "Wi-Fi" },
              { name: "tv", icon: <FaTv />, label: "TV" },
            ].map((a) => (
              <label
                key={a.name}
                className="flex items-center space-x-2 text-sm"
              >
                <input
                  type="checkbox"
                  checked={form.amenities[a.name]}
                  onChange={() => handleAmenityChange(a.name)}
                />
                <span className="flex items-center gap-2 text-gray-700">
                  {a.icon} {a.label}
                </span>
              </label>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition w-full sm:w-auto"
          >
            {editIndex !== null ? "Update Room" : "Save Room"}
          </button>
        </div>
      </form>

      {rooms.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {rooms.map((room, idx) => (
            <div
              key={idx}
              className="bg-white border rounded-lg shadow hover:shadow-lg transition"
            >
              {room.image && (
                <img
                  src={room.image}
                  alt="Room"
                  className="w-full h-48 object-cover rounded-t-lg"
                />
              )}
              <div className="p-4">
                <h5 className="font-bold text-lg text-gray-800">
                  {room.roomName}
                </h5>
                <p className="text-sm text-gray-600">Floor: {room.floor}</p>
                <p className="text-sm text-gray-600">Beds: {room.beds}</p>
                <p className="text-sm text-gray-600">Rent: ₹{room.rent}</p>
                <div className="flex gap-2 mt-2 text-green-600 text-lg">
                  {room.amenities.bed && <FaBed />}
                  {room.amenities.chair && <FaChair />}
                  {room.amenities.wifi && <FaWifi />}
                  {room.amenities.tv && <FaTv />}
                </div>
              </div>
              <div className="flex justify-between items-center border-t p-2">
                <button
                  onClick={() => handleEdit(idx)}
                  className="text-blue-600 hover:text-blue-800"
                >
                  <FaEdit />
                </button>
                <button
                  onClick={() => handleDelete(idx)}
                  className="text-red-600 hover:text-red-800"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RoomAdd;
