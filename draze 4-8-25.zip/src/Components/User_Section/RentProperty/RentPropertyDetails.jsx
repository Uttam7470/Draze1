// import React from "react";
// import { useLocation, useNavigate, useParams } from "react-router-dom";

// function RentPropertyDetail() {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const { id } = useParams();

//   const property = location.state;

//   if (!property) {
//     // ✅ If page refreshed, property will be null → handle it (fetch by id)
//     return (
//       <div className="p-6 max-w-4xl mx-auto text-center">
//         <p className="text-gray-600">Property not found.</p>
//         <button
//           onClick={() => navigate("/rent")}
//           className="mt-4 px-6 py-2 bg-blue-600 text-white rounded"
//         >
//           Back to List
//         </button>
//       </div>
//     );
//   }

//   return (
//     <div className="p-6 max-w-4xl mx-auto">
//       <button
//         onClick={() => navigate(-1)}
//         className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
//       >
//         ← Back
//       </button>
//       <div className="bg-white rounded-lg shadow-md overflow-hidden">
//         <img
//           src={property.image}
//           alt={property.name}
//           className="w-full h-64 object-cover"
//         />
//         <div className="p-6">
//           <h1 className="text-3xl font-bold mb-2">{property.name}</h1>
//           <p className="text-gray-600 mb-2">{property.location}</p>
//           <p className="text-lg font-semibold text-green-700 mb-2">
//             ₹{property.rent.toLocaleString()} / month
//           </p>
//           <p className="text-sm text-gray-500 mb-2">
//             {property.type} • {property.area} sq.ft
//           </p>
//           <p className="text-gray-700">{property.description}</p>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default RentPropertyDetail;



import React, { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";

function RentDetail() {
  const location = useLocation();
  const navigate = useNavigate();
  const property = location.state;

  useEffect(() => {
    AOS.init({ duration: 800, once: true });
    AOS.refresh();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  if (!property) {
    return (
      <div className="text-center mt-10">
        <p className="text-lg font-semibold">No property data found.</p>
        <button
          className="mt-4 bg-blue-500 text-white px-4 py-2 rounded"
          onClick={() => navigate(-1)}
        >
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto p-6">
      {/* Back Button */}
      <button
        className="mb-6 bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded text-gray-700"
        onClick={() => navigate(-1)}
        data-aos="fade-right"
      >
        ← Back
      </button>

      {/* Image */}
      <img
        src={property.image}
        alt={property.name}
        className="w-full h-72 object-cover rounded-lg mb-6 shadow-lg"
        data-aos="zoom-in"
      />

      {/* Details */}
      <h2
        className="text-3xl font-bold text-gray-800 mb-3"
        data-aos="fade-up"
      >
        {property.name}
      </h2>
      <p className="text-gray-700 mb-2" data-aos="fade-up" data-aos-delay="100">
        <strong>Location:</strong> {property.location}
      </p>
      <p className="text-gray-700 mb-2" data-aos="fade-up" data-aos-delay="200">
        <strong>Rent:</strong> ₹{property.rent.toLocaleString()} / month
      </p>
      <p className="text-gray-700 mb-2" data-aos="fade-up" data-aos-delay="300">
        <strong>Area:</strong> {property.area} sq.ft
      </p>
      <p className="text-gray-700 mb-2" data-aos="fade-up" data-aos-delay="400">
        <strong>Type:</strong> {property.type}
      </p>
      <p
        className="text-gray-700 mb-4"
        data-aos="fade-up"
        data-aos-delay="500"
      >
        <strong>Description:</strong> {property.description}
      </p>
    </div>
  );
}

export default RentDetail;
