import React from "react";

import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Autoplay, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

import CardCarousel from "../Card_Carousel/CardCarousel";

import AOS from "aos";
import "aos/dist/aos.css";
import "./RentalSlider.css";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useEffect } from "react";
import "./Main.css";
import pg_hostelData from "./pg-hostel";
import {
  FaMapMarkerAlt,
  FaHome,
  FaBed,
  FaRupeeSign,
  FaCheckCircle,
} from "react-icons/fa";

import {
  motion,
  useMotionValue,
  useTransform,
  useAnimation,
} from "framer-motion";

function MainPage() {
  const navigate = useNavigate();

  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);

  {
    showLogin && (
      <Login
        onClose={() => setShowLogin(false)}
        onRegisterClick={() => {
          setShowLogin(false);
          setShowSignup(true);
        }}
      />
    );
  }

  {
    showSignup && <SignupModal onClose={() => setShowSignup(false)} />;
  }

  const rentalProperties = [
    {
      id: 1,
      title: "Modern 2BHK Apartment",
      image:
        "https://plus.unsplash.com/premium_photo-1689609950069-2961f80b1e70?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cmVudGFsJTIwcHJvcGVydHl8ZW58MHx8MHx8fDA%3D",
      description:
        "Ideal for bachelors or couples, close to metro, with security and lift.",
    },
    {
      id: 2,
      title: "Luxury Studio Apartment",
      image:
        "https://images.unsplash.com/photo-1544984243-ec57ea16fe25?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cmVudGFsJTIwcHJvcGVydHl8ZW58MHx8MHx8fDA%3D",
      description:
        "Fully furnished studio with Wi-Fi, air conditioning, and premium furniture.",
    },
    {
      id: 3,
      title: "Family 3BHK Flat",
      image:
        "https://images.unsplash.com/photo-1650137938625-11576502aecd?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHJlbnRhbCUyMHByb3BlcnR5fGVufDB8fDB8fHww",
      description:
        "Perfect for families, near schools and market. Includes 2 bathrooms and a store room.",
    },
    {
      id: 4,
      title: "Cozy 1BHK in City Center",
      image:
        "https://media.istockphoto.com/id/1460658780/photo/for-rent-sign-in-front-of-house.webp?a=1&b=1&s=612x612&w=0&k=20&c=L8G2S6YCM-WQWc3r5HzoDxcX4hKilIgaiXTYH-ymLxI=",
      description:
        "Ideal for bachelors or couples, close to metro, with security and lift.",
    },
    {
      id: 5,
      title: "PG for Girls - AC Rooms",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwVeNLt82mCIUMFH_qB5wye9NNiyPeKSMjwQ&s",
      description:
        "Safe and secure PG accommodation with mess and housekeeping services included.",
    },
    {
      id: 6,
      title: "Modern 2BHK Apartment",
      image:
        "https://plus.unsplash.com/premium_photo-1689609950069-2961f80b1e70?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cmVudGFsJTIwcHJvcGVydHl8ZW58MHx8MHx8fDA%3D",
      description:
        "Ideal for bachelors or couples, close to metro, with security and lift.",
    },
    {
      id: 7,
      title: "Modern 2BHK Apartment",
      image:
        "https://plus.unsplash.com/premium_photo-1689609950069-2961f80b1e70?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8cmVudGFsJTIwcHJvcGVydHl8ZW58MHx8MHx8fDA%3D",
      description:
        "Ideal for bachelors or couples, close to metro, with security and lift.",
    },
  ];

  const images = [
    "https://plus.unsplash.com/premium_photo-1682377521697-bc598b52b08a?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8dmlsbGF8ZW58MHx8MHx8fDA%3D",
    "https://media.istockphoto.com/id/2204602504/photo/luxurious-lakeside-residence-with-manicured-gardens-and-dock-view.webp?a=1&b=1&s=612x612&w=0&k=20&c=lXYF230RtZORap6gkZwcTsh1KPKeqIh1fKmNZfMzFZI=",
    "https://plus.unsplash.com/premium_photo-1661883964999-c1bcb57a7357?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fGhvdXNlfGVufDB8fDB8fHww",
    "https://media.istockphoto.com/id/187324934/photo/repetitive-neighborhood.jpg?s=612x612&w=0&k=20&c=EdV51hq5ynKvncQ8rEHFQjzrsU0rMx7T-CAcPo859B8=",

  ];

  // const positions = [
  //   { top: "15%", left: "10%" },
  //   { top: "35%", left: "30%" },
  //   { top: "55%", left: "50%" },
  //   { top: "75%", left: "70%" },
  // ];

  //   const particles = Array.from({ length: 25 }).map(() => ({
  //   top: `${Math.random() * 100}%`,
  //   left: `${Math.random() * 100}%`,
  //   size: Math.random() * 4 + 2,
  //   duration: Math.random() * 5 + 3,
  // }));

  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  const [angle, setAngle] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAngle((prev) => prev + 0.01); // adjust speed
    }, 16); // ~60fps

    return () => clearInterval(interval);
  }, []);



  const particles = Array.from({ length: 30 }).map(() => ({
    top: Math.random() * 100,
    left: Math.random() * 100,
    size: Math.random() * 4 + 2,
    speed: Math.random() * 0.05 + 0.02, // speed for "magnet effect"
  }));

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMouse({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const handleMouseMove = (e) => {
    const { innerWidth, innerHeight } = window;
    const x = (e.clientX / innerWidth - 0.5) * 40;
    const y = (e.clientY / innerHeight - 0.5) * 40;
    setMousePos({ x, y });
  };

  const shapes = [
    { size: 50, top: "10%", left: "20%", color: "#5C4EFF" },
    { size: 80, top: "30%", left: "70%", color: "#FF7A59" },
    { size: 40, top: "60%", left: "10%", color: "#00C9A7" },
    { size: 60, top: "50%", left: "50%", color: "#FFD93D" },
  ];
 

  const positions = [
    { top: "10%", left: "10%" }, // Position 1 (top-left)
    { top: "10%", left: "70%" }, // Position 2 (top-right)
    { top: "60%", left: "70%" }, // Position 3 (bottom-right)
    { top: "60%", left: "10%" }, // Position 4 (bottom-left)
  ];

  const durationPerStep = 3;

  const totalDuration = positions.length * durationPerStep;

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section
        className="h-[90vh] bg-center bg-no-repeat flex items-center justify-center text-white text-center relative"
        style={{
          //   backgroundImage: `url('https://images.unsplash.com/photo-1498373419901-52eba931dc4f?w=1600&auto=format&fit=crop&q=80')`,
          backgroundImage: `url('https://media.istockphoto.com/id/1223059837/photo/cityscape-of-a-modern-residential-area-with-apartment-buildings-new-green-urban-landscape-in.webp?a=1&b=1&s=612x612&w=0&k=20&c=6xDsp8tz1LG0GBNe6OkZ70JFK4DdS7EinETappvzef4=')`,
          backgroundSize: "cover",
          opacity: "1",
        }}
      >
        <div className="bg-black/40 absolute inset-0" />
        <div className="relative z-10 px-6" data-aos="fade-up">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Welcome to Draze Living
          </h1>
          <p className="text-lg md:text-2xl max-w-xl mx-auto mb-6">
            Discover rental properties, PGs, hostels & more — designed for your
            comfort.
          </p>

          {/* Hero Buttons */}
          <div className="flex flex-wrap justify-center gap-6 mt-20">
            <button
              onClick={() => navigate("/rent")}
              className="glow-border-btn"
              style={{
                padding: "10px 24px",
              }}
            >
              For Rent
            </button>
            <button
              onClick={() => navigate("/sell")}
              className="glow-border-btn"
            >
              For Sell
            </button>
            <button
              onClick={() => navigate("/hotel")}
              className="glow-border-btn"
            >
              Hotel & Banquet
            </button>
            <button
              onClick={() => navigate("/pg")}
              className="glow-border-btn"
              style={{
                padding: "10px 40px",
              }}
            >
              PG
            </button>
            <button
              onClick={() => navigate("/hostel")}
              className="glow-border-btn"
              style={{
                padding: "10px 30px",
              }}
            >
              Hostel
            </button>
          </div>
        </div>
      </section>

      {/* PG & Hostel Section */}

      <section className="py-16 px-6 bg-gray-50 text-center">
        <h2
          className="text-3xl font-bold text-[#183c2c] mb-10"
          data-aos="fade-up"
        >
          Affordable PGs & Hostels
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {pg_hostelData.map((item, index) => (
            <div
              key={item.id}
              className="bg-white rounded-xl shadow hover:shadow-lg transition overflow-hidden text-left"
              data-aos="zoom-in"
              data-aos-delay={index * 100}
            >
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover"
              />

              <div className="p-4 space-y-3">
                <h3 className="text-xl font-bold text-center text-[#5C4EFF]">
                  {item.name}
                </h3>

                <p className="flex items-center text-gray-600 text-sm gap-2">
                  <FaMapMarkerAlt className="text-[#5C4EFF]" />
                  {item.city}, {item.location}
                </p>

                {/* Description */}
                {/* <p className="text-sm text-gray-700">{item.description}</p> */}

                {/* Property Type */}
                <p className="flex items-center text-sm gap-2">
                  <FaHome className="text-[#5C4EFF]" />
                  <span className="font-semibold">Type:</span>{" "}
                  {item.propertyType}
                </p>

                {/* Bedrooms */}
                <p className="flex items-center text-sm gap-2">
                  <FaBed className="text-[#5C4EFF]" />
                  <span className="font-semibold">Bedrooms:</span>{" "}
                  {item.bedrooms}
                </p>

                {/* Price */}
                <p className="flex items-center text-sm gap-2">
                  <FaRupeeSign className="text-[#5C4EFF]" />
                  <span className="font-semibold">Price:</span> ₹{item.price}
                  /month
                </p>

                {/* Amenities */}
                <div className="flex items-start gap-2 text-sm">
                  <FaCheckCircle className="mt-1 text-[#5C4EFF]" />
                  <div>
                    <span className="font-semibold">Amenities:</span>{" "}
                    {item.amenities.join(", ")}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Swiper Rental Properties Section */}

      {/* <section className="py-16 px-6 bg-white text-center">
      <h2 className="text-3xl font-bold text-[#183c2c] mb-10" data-aos="fade-up">
        Popular Rental Properties
      </h2>

      <div className="max-w-6xl mx-auto relative">
        <Swiper
          modules={[Pagination, Autoplay, Navigation]}
          spaceBetween={30}
          slidesPerView={1}
          pagination={{
            clickable: true,
          }}
          navigation={true}
          loop={true}
          autoplay={{
            delay: 3000,
            // disableOnInteraction: false,
            // pauseOnMouseEnter: true,
          }}
          breakpoints={{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }}
          className="pb-16"
        >
          {rentalProperties.map((property, index) => (
            <SwiperSlide key={property.id}>
              <div
                className="bg-gray-50 rounded-xl shadow hover:shadow-lg transition overflow-hidden"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <img
                  src={property.image}
                  alt={property.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-[#5C4EFF] mb-2">
                    {property.title}
                  </h3>
                  <p className="text-gray-700">{property.description}</p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>

        
      </div>
    </section> */}

      <section className="py-16 px-6 bg-white text-center">
        <h2 className="text-3xl font-bold text-[#183c2c] mb-10">
          Popular Rental Properties
        </h2>

        <div className="max-w-6xl mx-auto relative">
          <CardCarousel items={rentalProperties} />
        </div>
      </section>



      {/* Banner Section */}


      <section
      className="relative h-[400px] rounded-xl mx-6 mt-16 overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            "linear-gradient(135deg, #1e3c72, #2a5298)",
            "linear-gradient(135deg, #6a11cb, #2575fc)",
            "linear-gradient(135deg, #11998e, #38ef7d)",
          ],
        }}
        transition={{ duration: 8, repeat: Infinity, repeatType: "reverse" }}
      />

     
      {images.map((img, i) => (
        <motion.img
          key={i}
          src={img}
          className="absolute w-32 h-32 object-cover rounded-lg border-4 border-white shadow-lg"
          style={{
            top: i < 2 ? "15%" : "60%",
            left: i % 2 === 0 ? "10%" : "75%",
            rotate: "45deg",
          }}
          animate={{
            x: [0, i % 2 === 0 ? 10 : -10, 0],
            y: [0, i < 2 ? -15 : 15, 0],
            rotate: [45, 48, 45],
          }}
          transition={{ repeat: Infinity, duration: 3 + i }}
          whileHover={{ scale: 1.1 }}
        />
      ))}

      <motion.div
        className="absolute inset-0 flex flex-col items-center justify-center text-center text-white"
        style={{
          transform: `translate(${mousePos.x / 10}px, ${mousePos.y / 10}px)`,
        }}
      >
        <motion.h2
          className="text-4xl md:text-3xl font-bold"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Start your journey with{" "}
          <span className="text-yellow-300">Draze Living</span>
        </motion.h2>
        <motion.p
          className="mt-3 text-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          Find rentals, PGs & hostels like never before.
        </motion.p>
      </motion.div>
    </section>

      



      



     

      {/* this good banner */}

      {/* <section className="relative h-[70vh] bg-gradient-to-br from-[#1b1b3a] via-[#2e2e6f] to-[#1b1b3a] rounded-xl mx-6 overflow-hidden">
      
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1),transparent_70%)] z-0" />

      {shapes.map((shape, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full opacity-70 blur-md"
          style={{
            width: shape.size,
            height: shape.size,
            top: shape.top,
            left: shape.left,
            backgroundColor: shape.color,
          }}
          animate={{
            y: [0, -20, 0],
            x: [0, 10, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 5 + i,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}

      
      {[...Array(10)].map((_, index) => (
        <motion.span
          key={index}
          className="absolute w-1 h-1 bg-white rounded-full"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          animate={{
            opacity: [0, 1, 0],
            y: [-10, 10],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            delay: index * 0.2,
          }}
        />
      ))}

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center text-white">
        <motion.h2
          className="text-4xl md:text-5xl font-bold mb-4"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Elevate Your Living with{" "}
          <span className="text-[#FFD93D]">Draze</span> Properties
        </motion.h2>

        <motion.p
          className="text-lg md:text-xl max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          Modern rentals, PGs, hostels & luxury homes with stunning amenities.
        </motion.p>
      </div>
    </section> */}
    </div>
  );
}

export default MainPage;
