import React, { useEffect } from "react";
import { useLocation, useParams } from "react-router-dom";
import AOS from "aos";
import "aos/dist/aos.css";

const PGDetails = () => {
  const { state } = useLocation();
  const { id } = useParams();
  const pg = state;

  useEffect(() => {
    AOS.init({ duration: 800, once: true });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  if (!pg)
    return <div className="text-center mt-10">PG not found.</div>;

  return (
    <div
      className="max-w-4xl mx-auto p-6 mt-10 bg-white shadow-md rounded-xl"
      data-aos="fade-up"
    >
      <h1
        className="text-3xl font-bold mb-4 text-center"
        data-aos="zoom-in"
      >
        {pg.name}
      </h1>

      <div
        className="w-full h-64 overflow-hidden rounded-lg mb-6"
        data-aos="fade-up"
      >
        <img
          src={pg.image}
          alt={pg.name}
          className="w-full h-full object-cover"
        />
      </div>

      <div
        className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-gray-800"
        data-aos="fade-up"
      >
        <div data-aos="fade-right">
          <h2 className="text-lg font-semibold">Location</h2>
          <p>{pg.location}, {pg.city}</p>
        </div>

        <div data-aos="fade-left">
          <h2 className="text-lg font-semibold">Price</h2>
          <p>₹ {pg.price}</p>
        </div>

        <div data-aos="fade-right">
          <h2 className="text-lg font-semibold">Bedrooms</h2>
          <p>{pg.bedrooms}</p>
        </div>

        <div data-aos="fade-left">
          <h2 className="text-lg font-semibold">Property Type</h2>
          <p>{pg.propertyType}</p>
        </div>

        <div data-aos="fade-right">
          <h2 className="text-lg font-semibold">Status</h2>
          <p>{pg.status}</p>
        </div>

        <div data-aos="fade-left">
          <h2 className="text-lg font-semibold">Amenities</h2>
          <ul className="list-disc list-inside">
            {pg.amenities &&
              pg.amenities.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
          </ul>
        </div>

        <div
          className="sm:col-span-2"
          data-aos="fade-up"
        >
          <h2 className="text-lg font-semibold">Description</h2>
          <p className="text-gray-600">{pg.description}</p>
        </div>
      </div>
    </div>
  );
};

export default PGDetails;
 