
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  FaTachometerAlt,
  FaPlus,
  FaBuilding,
  FaUserFriends,
  FaUser,
  FaListAlt,
  FaBars,
} from "react-icons/fa";
import drazeLogo from '../../../assets/logo/drazeLogo.png';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleSidebar = () => setIsOpen(!isOpen);
  const closeSidebar = () => setIsOpen(false);
  const isActive = (path) => location.pathname === path;

  return (
    <>
      {/* Mobile Toggle Button */}
      <button
        className="md:hidden fixed top-3 left-3 z-50 bg-indigo-600 text-white p-2 rounded shadow"
        onClick={toggleSidebar}
        aria-label="Toggle sidebar"
      >
        <FaBars />
      </button>

      {/* Sidebar */}
      <div
  className={`h-screen w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out
    ${isOpen ? "translate-x-0 fixed z-50" : "-translate-x-full fixed z-50"}
    md:translate-x-0 md:relative md:z-0`}
>

        {/* Logo */}
        <div className="flex justify-center items-center py-4 border-b border-gray-200">
          <img
            src={drazeLogo}
            alt="Draze Logo"
            className="w-[clamp(120px,40vw,150px)] h-auto object-contain"
          />
        </div>

        {/* Navigation Links */}
        <div className="flex flex-col justify-between h-[calc(100vh-88px)] px-4 py-4">
          <ul className="space-y-2">
            <SidebarLink to="/landlord" icon={<FaTachometerAlt />} label="Home" active={isActive("/")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/property" icon={<FaBuilding />} label="Properties" active={isActive("/property")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/add-property" icon={<FaPlus />} label="Add Property" active={isActive("/add-property")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/room-overview" icon={<FaListAlt />} label="Rooms" active={isActive("/room-overview")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/tenants" icon={<FaUserFriends />} label="Tenants" active={isActive("/tenants")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/property-list" icon={<FaListAlt />} label="Listings" active={isActive("/property-list")} onClick={closeSidebar} />
            <SidebarLink to="/landlord/landlord-profile" icon={<FaUser />} label="Profile" active={isActive("/landlord-profile")} onClick={closeSidebar} />
          </ul>
        </div>
      </div>

      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed bg-opacity-40 z-30 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </>
  );
};

const SidebarLink = ({ to, icon, label, active, onClick }) => (
  <li>
    <Link
      to={to}
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-2 rounded transition-colors ${
        active
          ? "bg-indigo-100 text-indigo-600 font-semibold"
          : "text-indigo-500 hover:bg-indigo-100"
      }`}
    >
      <span className="text-xl">{icon}</span>
      <span className="text-sm sm:text-base">{label}</span>
    </Link>
  </li>
);

export default Sidebar;

