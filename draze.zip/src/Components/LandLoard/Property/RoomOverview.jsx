import React, { useState } from "react";
import { FaDoorOpen } from "react-icons/fa";
import { Link } from "react-router-dom";

const RoomOverview = () => {
  const roomStats = [
    { label: "Total Rooms", count: 0 },
    { label: "Total Beds", count: 0 },
    { label: "Vacant Rooms", count: 0 },
  ];

  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="p-4 w-full">
      <h3 className="text-xl sm:text-2xl font-bold mb-6">Room Overview</h3>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        {roomStats.map((stat, index) => (
          <div
            key={index}
            className="bg-white border rounded-lg shadow-sm p-5 text-center"
          >
            <h2 className="text-2xl text-blue-600 font-bold">{stat.count}</h2>
            <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="mb-6">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search Room..."
          className="w-full sm:w-96 px-4 py-2 border rounded-md focus:ring-blue-500 focus:border-blue-500"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto bg-white rounded-lg shadow-sm">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-100 text-xs text-gray-600 uppercase">
            <tr>
              <th className="px-4 py-2">Floor</th>
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Occupancy</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2">Rent/Bed</th>
              <th className="px-4 py-2">Remarks</th>
              <th className="px-4 py-2">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan="7" className="text-center text-gray-400 py-6">
                No data available
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Add Room */}
      <div className="mt-6 text-right">
        <Link to="/add-room">
          <button className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
            <FaDoorOpen className="mr-2" />
            Add Room
          </button>
        </Link>
      </div>
    </div>
  );
};

export default RoomOverview;
