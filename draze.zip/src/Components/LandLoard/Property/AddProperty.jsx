import React, { useState, useEffect } from "react";

const initialFormState = {
  title: localStorage.getItem("title") || "",
  type: localStorage.getItem("type") || "",
  bedrooms: localStorage.getItem("bedrooms") || "",
  address: localStorage.getItem("address") || "",
  city: localStorage.getItem("city") || "",
  state: localStorage.getItem("state") || "",
  pincode: localStorage.getItem("pincode") || "",
  description: localStorage.getItem("description") || "",
  roomType: localStorage.getItem("roomType") || "",
  rooms: localStorage.getItem("rooms") || "",
  images: JSON.parse(localStorage.getItem("images")) || [],
  roomDetails: JSON.parse(localStorage.getItem("roomDetails")) || [],
  bedDetails: JSON.parse(localStorage.getItem("bedDetails")) || [],
};

const AddProperty = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [imagePreviews, setImagePreviews] = useState(initialFormState.images);
  const [showRoomFields, setShowRoomFields] = useState(false);
  const [showBedFields, setShowBedFields] = useState(false);
  const [currentRoom, setCurrentRoom] = useState({ type: "", count: "" });
  const [currentBed, setCurrentBed] = useState({ type: "", count: "" });

  useEffect(() => {
    setImagePreviews(JSON.parse(localStorage.getItem("images")) || []);
    setFormData((prev) => ({
      ...prev,
      roomDetails: JSON.parse(localStorage.getItem("roomDetails")) || [],
      bedDetails: JSON.parse(localStorage.getItem("bedDetails")) || [],
    }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    localStorage.setItem(name, value);
  };

  const handleRoomChange = (e) => {
    const { name, value } = e.target;
    setCurrentRoom((prev) => ({ ...prev, [name]: value }));
  };

  const handleBedChange = (e) => {
    const { name, value } = e.target;
    setCurrentBed((prev) => ({ ...prev, [name]: value }));
  };

  const convertToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleImageChange = async (e) => {
    const files = Array.from(e.target.files).slice(0, 5);
    const base64Images = await Promise.all(
      files.map((file) => convertToBase64(file))
    );
    setFormData((prev) => {
      localStorage.setItem("images", JSON.stringify(base64Images));
      return { ...prev, images: base64Images };
    });
    setImagePreviews(base64Images);
  };

  const handleAddRoom = () => {
    if (!currentRoom.type || !currentRoom.count) {
      alert("Please fill Room Type and Number of Rooms.");
      return;
    }
    const newRoomDetails = [
      ...formData.roomDetails,
      { type: currentRoom.type, count: currentRoom.count, id: Date.now() },
    ];
    setFormData((prev) => ({
      ...prev,
      roomDetails: newRoomDetails,
    }));
    localStorage.setItem("roomDetails", JSON.stringify(newRoomDetails));
    setCurrentRoom({ type: "", count: "" });
    setShowRoomFields(false);
  };

  const handleAddBed = () => {
    if (!currentBed.type || !currentBed.count) {
      alert("Please fill Bed Type and Number of Beds.");
      return;
    }
    const newBedDetails = [
      ...formData.bedDetails,
      { type: currentBed.type, count: currentBed.count, id: Date.now() },
    ];
    setFormData((prev) => ({
      ...prev,
      bedDetails: newBedDetails,
    }));
    localStorage.setItem("bedDetails", JSON.stringify(newBedDetails));
    setCurrentBed({ type: "", count: "" });
    setShowBedFields(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      !formData.title ||
      !formData.type ||
      !formData.address ||
      !formData.city ||
      !formData.state ||
      !formData.pincode
    ) {
      alert(
        "Please fill all required fields (Property Name, Type, Address, City, State, Pincode)."
      );
      return;
    }

    if (formData.images.length === 0) {
      alert("Please upload at least one image.");
      return;
    }

    const existing = JSON.parse(localStorage.getItem("properties")) || [];
    const newProperty = { ...formData, id: Date.now() };
    const updated = [...existing, newProperty];

    localStorage.setItem("properties", JSON.stringify(updated));

    alert("Property submitted successfully!");

    setFormData(initialFormState);
    setImagePreviews([]);
    Object.keys(initialFormState).forEach((key) => localStorage.removeItem(key));
    localStorage.removeItem("images");
    localStorage.removeItem("roomDetails");
    localStorage.removeItem("bedDetails");
    setShowRoomFields(false);
    setShowBedFields(false);
  };

  return (
    <section className="py-6 sm:py-8 bg-gradient-to-b from-gray-50 to-gray-100 min-h-screen">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-2xl p-4 sm:p-6 lg:p-8 border border-gray-200 max-w-4xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-6 sm:mb-8 text-blue-700">
            Add New Property
          </h2>
          <div>
            <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2">
              {/* Basic Info */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Name</label>
                <input
                  name="title"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Enter Property Title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Type</label>
                <select
                  name="type"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  value={formData.type}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Property Type</option>
                  <option>PG</option>
                  <option>Hostel</option>
                  <option>Flat</option>
                  <option>Apartment</option>
                  <option>Villa</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Description</label>
                <textarea
                  name="description"
                  rows="4"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Describe the Property"
                  value={formData.description}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bedrooms</label>
                <input
                  name="bedrooms"
                  type="number"
                  min="0"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Number of Bedrooms"
                  value={formData.bedrooms}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Default Room Type</label>
                <select
                  name="roomType"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  value={formData.roomType}
                  onChange={handleChange}
                >
                  <option value="">Select Room Type</option>
                  <option value="Single Room">Single Room</option>
                  <option value="Double Room">Double Room</option>
                  <option value="Shared Room">Shared Room</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Address</label>
                <input
                  name="address"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Enter Full Address"
                  value={formData.address}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                <input
                  name="city"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Enter City"
                  value={formData.city}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                <input
                  name="state"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Enter State"
                  value={formData.state}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pincode</label>
                <input
                  name="pincode"
                  type="text"
                  className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                  placeholder="Enter Pincode"
                  value={formData.pincode}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Image Upload */}
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Upload Images (up to 5)</label>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="w-full p-3 rounded-lg border-2 border-gray-300 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200 transition-all duration-200"
                  onChange={handleImageChange}
                />
                <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {imagePreviews.map((img, index) => (
                    <img
                      key={index}
                      src={img}
                      alt={`preview ${index}`}
                      className="h-24 sm:h-32 w-full object-cover rounded-lg border border-gray-200 shadow-sm"
                    />
                  ))}
                </div>
              </div>

              {/* Add Room Button */}
              <div className="sm:col-span-2 text-center">
                {!showRoomFields ? (
                  <button
                    type="button"
                    className="w-full sm:w-auto px-6 py-2 bg-blue-100 text-blue-700 font-semibold rounded-lg border-2 border-blue-500 hover:bg-blue-200 hover:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200"
                    onClick={() => setShowRoomFields(true)}
                  >
                    ➕ Add Room Details
                  </button>
                ) : (
                  <div className="flex flex-col sm:flex-row justify-center gap-3">
                    <button
                      type="button"
                      className="w-full sm:w-auto px-6 py-2 bg-blue-100 text-blue-700 font-semibold rounded-lg border-2 border-blue-500 hover:bg-blue-200 hover:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200"
                      onClick={handleAddRoom}
                    >
                      Save Room Details
                    </button>
                    <button
                      type="button"
                      className="w-full sm:w-auto px-6 py-2 bg-gray-100 text-gray-700 font-semibold rounded-lg border-2 border-gray-400 hover:bg-gray-200 hover:border-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-all duration-200"
                      onClick={() => setShowRoomFields(false)}
                    >
                      ➖ Cancel
                    </button>
                  </div>
                )}
              </div>

              {/* Room Fields */}
              {showRoomFields && (
                <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Room Type</label>
                    <select
                      name="type"
                      className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                      value={currentRoom.type}
                      onChange={handleRoomChange}
                    >
                      <option value="">Select Room Type</option>
                      <option value="Single Room">Single Room</option>
                      <option value="Double Room">Double Room</option>
                      <option value="Shared Room">Shared Room</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Number of Rooms</label>
                    <input
                      name="count"
                      type="number"
                      min="0"
                      className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                      placeholder="Number of Rooms"
                      value={currentRoom.count}
                      onChange={handleRoomChange}
                    />
                  </div>
                </div>
              )}

              {/* Display Added Rooms */}
              {formData.roomDetails.length > 0 && (
                <div className="sm:col-span-2">
                  <h5 className="text-lg font-semibold text-gray-800 mb-3">Added Rooms</h5>
                  <ul className="space-y-3">
                    {formData.roomDetails.map((room) => (
                      <li key={room.id} className="p-3 bg-gray-50 rounded-lg border-2 border-gray-200 shadow-sm">
                        {room.type} - {room.count} Room(s)
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Add Bed Button */}
              {formData.roomDetails.length > 0 && (
                <div className="sm:col-span-2 text-center">
                  {!showBedFields ? (
                    <button
                      type="button"
                      className="w-full sm:w-auto px-6 py-2 bg-blue-100 text-blue-700 font-semibold rounded-lg border-2 border-blue-500 hover:bg-blue-200 hover:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200"
                      onClick={() => setShowBedFields(true)}
                    >
                      ➕ Add Bed Details
                    </button>
                  ) : (
                    <div className="flex flex-col sm:flex-row justify-center gap-3">
                      <button
                        type="button"
                        className="w-full sm:w-auto px-6 py-2 bg-blue-100 text-blue-700 font-semibold rounded-lg border-2 border-blue-500 hover:bg-blue-200 hover:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200"
                        onClick={handleAddBed}
                      >
                        Save Bed Details
                      </button>
                      <button
                        type="button"
                        className="w-full sm:w-auto px-6 py-2 bg-gray-100 text-gray-700 font-semibold rounded-lg border-2 border-gray-400 hover:bg-gray-200 hover:border-gray-500 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-all duration-200"
                        onClick={() => setShowBedFields(false)}
                      >
                        ➖ Cancel
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Bed Fields */}
              {showBedFields && (
                <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Bed Type</label>
                    <select
                      name="type"
                      className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                      value={currentBed.type}
                      onChange={handleBedChange}
                    >
                      <option value="">Select Bed Type</option>
                      <option value="Single Bed">Single Bed</option>
                      <option value="Double Bed">Double Bed</option>
                      <option value="Queen Bed">Queen Bed</option>
                      <option value="King Bed">King Bed</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Number of Beds</label>
                    <input
                      name="count"
                      type="number"
                      min="0"
                      className="w-full p-3 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200"
                      placeholder="Number of Beds"
                      value={currentBed.count}
                      onChange={handleBedChange}
                    />
                  </div>
                </div>
              )}

              {/* Display Added Beds */}
              {formData.bedDetails.length > 0 && (
                <div className="sm:col-span-2">
                  <h5 className="text-lg font-semibold text-gray-800 mb-3">Added Beds</h5>
                  <ul className="space-y-3">
                    {formData.bedDetails.map((bed) => (
                      <li key={bed.id} className="p-3 bg-gray-50 rounded-lg border-2 border-gray-200 shadow-sm">
                        {bed.type} - {bed.count} Bed(s)
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Submit Button */}
              <div className="sm:col-span-2 text-center mt-6">
                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200"
                  onClick={handleSubmit}
                >
                  Submit Property
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AddProperty;