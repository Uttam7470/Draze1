

// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import AOS from "aos";
// import "aos/dist/aos.css";
// // import Navbar from ".User_Section/Components/Navbar/navbar";
// import Navbar from './Components/User_Section/Navbar/navbar'
// import Footer from "./Components/User_Section/Footer/footer";
// import MainPage from "./Components/User_Section/Main/MainPage";
// import AllProperty from "./Components/User_Section/AllProperty/AllProperty";
// import PropertyDetails from "./Components/User_Section/AllProperty/PropertyDetails";
// import PG from "./Components/User_Section/PG/PG";
// import { useEffect } from "react";
// import PgDetails from "./Components/User_Section/PG/PgDetails";
// import Login from "./Components/User_Section/Login&Signup/Login";
// import Signup from "./Components/User_Section/Login&Signup/Signup";
// import RentProperty from "./Components/User_Section/RentProperty/RentProperty";
// import SellProperty from "./Components/User_Section/SellProperty/SellProperty";
// import Contact from "./Components/User_Section/Contact/Contact";
// import Hostel from "./Components/User_Section/Hostel/Hostel";
// import Hotel_Banqute from "./Components/User_Section/Hotel_Banqute/Hotel_Banqute";
// import RentPropertyDetail from "./Components/User_Section/RentProperty/RentPropertyDetails";
// import SellPropertyDetail from "./Components/User_Section/SellProperty/SellPropertyDetail";
// import Hotel_BanquteDetails from "./Components/User_Section/User_Section/Hotel_Banqute/Hotel_BanquteDetails";
// import HostelDetail from "./Components/User_Section/Hostel/HostelDetail";
// import { AuthProvider } from "./Components/User_Section/Context/AuthContext";

// // ✅ Import User Section components
// import UserLayout from "./Components/User_Section/UserSection/UserLayout";
// import ProfilePage from "./Components/User_Section/UserSection/pages/ProfilePage";
// import BookingsPage from "./Components/User_Section/UserSection/pages/BookingPage";

// function App() {
//   useEffect(() => {
//     AOS.init({ duration: 1000 });
//   }, []);

//   return (
//     <AuthProvider>
//       <Router>
//         <div className="flex flex-col min-h-screen">
//           <Navbar />

//           {/* Page Content */}
//           <div className="flex-grow pt-20">
//             <Routes>
//               {/* General Routes */}
//               <Route path="/" element={<MainPage />} />
//               <Route path="/properties" element={<AllProperty />} />
//               <Route path="/property/:id" element={<PropertyDetails />} />
//               <Route path="/pg" element={<PG />} />
//               <Route path="/pg/:id" element={<PgDetails />} />
//               <Route path="/contact" element={<Contact />} />
//               <Route path="/hostel" element={<Hostel />} />
//               <Route path="/hostel/:id" element={<HostelDetail />} />
//               <Route path="/login" element={<Login />} />
//               <Route path="/signup" element={<Signup />} />
//               <Route path="/rent" element={<RentProperty />} />
//               <Route path="/rent/:id" element={<RentPropertyDetail />} />
//               <Route path="/sell" element={<SellProperty />} />
//               <Route path="/sell/:id" element={<SellPropertyDetail />} />
//               <Route path="/hotel" element={<Hotel_Banqute />} />
//               <Route path="/hotel/:id" element={<Hotel_BanquteDetails />} />

//               {/* ✅ User Section Routes */}
//               <Route path="/user" element={<UserLayout />}>
//                 <Route path="profile" element={<ProfilePage />} />
//                 <Route path="bookings" element={<BookingsPage />} />
//               </Route>
//             </Routes>
//           </div>

//           <Footer />
//         </div>
//       </Router>
//     </AuthProvider>
//   );
// }

// export default App;





// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import AOS from "aos";
// import "aos/dist/aos.css";
// import { useEffect } from "react";

// // ✅ Context
// import { AuthProvider } from "./Components/User_Section/Context/AuthContext";

// // ✅ Main Site Layout Components
// import Navbar from "./Components/User_Section/Navbar/navbar";
// import Footer from "./Components/User_Section/Footer/footer";

// // ✅ Main Site Pages
// import MainPage from "./Components/User_Section/Main/MainPage";
// import AllProperty from "./Components/User_Section/AllProperty/AllProperty";
// import PropertyDetails from "./Components/User_Section/AllProperty/PropertyDetails";
// import PG from "./Components/User_Section/PG/PG";
// import PgDetails from "./Components/User_Section/PG/PgDetails";
// import Login from "./Components/User_Section/Login&Signup/Login";
// import Signup from "./Components/User_Section/Login&Signup/Signup";
// import RentProperty from "./Components/User_Section/RentProperty/RentProperty";
// import SellProperty from "./Components/User_Section/SellProperty/SellProperty";
// import Contact from "./Components/User_Section/Contact/Contact";
// import Hostel from "./Components/User_Section/Hostel/Hostel";
// import HostelDetail from "./Components/User_Section/Hostel/HostelDetail";
// import Hotel_Banqute from "./Components/User_Section/Hotel_Banqute/Hotel_Banqute";
// import Hotel_BanquteDetails from "./Components/User_Section/Hotel_Banqute/Hotel_BanquteDetails";
// import RentPropertyDetail from "./Components/User_Section/RentProperty/RentPropertyDetails";
// import SellPropertyDetail from "./Components/User_Section/SellProperty/SellPropertyDetail";

// // ✅ User Section (Dashboard) Layout & Pages
// import UserLayout from "./Components/User_Section/UserSection/UserLayout";
// import ProfilePage from "./Components/User_Section/UserSection/pages/ProfilePage";
// import BookingsPage from "./Components/User_Section/UserSection/pages/BookingPage";

// function App() {
//   useEffect(() => {
//     AOS.init({ duration: 1000 });
//   }, []);

//   return (
//     <AuthProvider>
//       <Router>
//         <Routes>
//           {/* Main Site Layout with Navbar & Footer */}
//           <Route
//             path="*"
//             element={
//               <div className="flex flex-col min-h-screen">
//                 <Navbar />
//                 <div className="flex-grow pt-20">
//                   <Routes>
//                     <Route path="/" element={<MainPage />} />
//                     <Route path="/properties" element={<AllProperty />} />
//                     <Route path="/property/:id" element={<PropertyDetails />} />
//                     <Route path="/pg" element={<PG />} />
//                     <Route path="/pg/:id" element={<PgDetails />} />
//                     <Route path="/contact" element={<Contact />} />
//                     <Route path="/hostel" element={<Hostel />} />
//                     <Route path="/hostel/:id" element={<HostelDetail />} />
//                     <Route path="/login" element={<Login />} />
//                     <Route path="/signup" element={<Signup />} />
//                     <Route path="/rent" element={<RentProperty />} />
//                     <Route path="/rent/:id" element={<RentPropertyDetail />} />
//                     <Route path="/sell" element={<SellProperty />} />
//                     <Route path="/sell/:id" element={<SellPropertyDetail />} />
//                     <Route path="/hotel" element={<Hotel_Banqute />} />
//                     <Route path="/hotel/:id" element={<Hotel_BanquteDetails />} />
//                   </Routes>
//                 </div>
//                 <Footer />
//               </div>
//             }
//           />

//           {/* User Dashboard Section (already includes header/footer inside layout) */}
//           <Route path="/user" element={<UserLayout />}>
//             <Route path="profile" element={<ProfilePage />} />
//             <Route path="bookings" element={<BookingsPage />} />
//           </Route>
//         </Routes>
//       </Router>
//     </AuthProvider>
//   );
// }

// export default App;




import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";

// ✅ Auth context
import { AuthProvider } from "./Components/User_Section/Context/AuthContext";

// ✅ Layouts
import UserLayout from "./Components/User_Section/UserSection/UserLayout";
// import LandlordLayout from "./Components/Layout/Layout"; 
import Layou from './Components/LandLoard/Layout/Layout'

// ✅ Main Website Components
import Navbar from "./Components/User_Section/Navbar/navbar";
import Footer from "./Components/User_Section/Footer/footer";
import MainPage from "./Components/User_Section/Main/MainPage";
import AllProperty from "./Components/User_Section/AllProperty/AllProperty";
import PropertyDetails from "./Components/User_Section/AllProperty/PropertyDetails";
import PG from "./Components/User_Section/PG/PG";
import PgDetails from "./Components/User_Section/PG/PgDetails";
import Login from "./Components/User_Section/Login&Signup/Login";
import Signup from "./Components/User_Section/Login&Signup/Signup";
import RentProperty from "./Components/User_Section/RentProperty/RentProperty";
import SellProperty from "./Components/User_Section/SellProperty/SellProperty";
import Contact from "./Components/User_Section/Contact/Contact";
import Hostel from "./Components/User_Section/Hostel/Hostel";
import HostelDetail from "./Components/User_Section/Hostel/HostelDetail";
import Hotel_Banqute from "./Components/User_Section/Hotel_Banqute/Hotel_Banqute";
import Hotel_BanquteDetails from "./Components/User_Section/Hotel_Banqute/Hotel_BanquteDetails";
import RentPropertyDetail from "./Components/User_Section/RentProperty/RentPropertyDetails";
import SellPropertyDetail from "./Components/User_Section/SellProperty/SellPropertyDetail";

// ✅ User Pages
import ProfilePage from "./Components/User_Section/UserSection/pages/ProfilePage";
import BookingsPage from "./Components/User_Section/UserSection/pages/BookingPage";

// ✅ Landlord Dashboard Pages
// import Dashboard from "./Components/Dashboard/Dashboard";
import Dashboard from './Components/LandLoard/Dashboard/Dashboard'
// import AddProperty from ".Components/LandLoard/Property/AddProperty";
import AddProperty from './Components/LandLoard/Property/AddProperty'
import Tenants from "./Components/LandLoard/Tenant/Tenant";
import PropertyDetail from "./Components/LandLoard/Property/PropertyDetail";
import PropertyList from "./Components/LandLoard/Property/Propertylist";
import Property from "./Components/LandLoard/Property/Property";
import RoomOverview from "./Components/LandLoard/Property/RoomOverview";
import TenantForm from "./Components/LandLoard/Tenant/TenantForm";
import LandlordProfile from "./Components/LandLoard/Profile/LandlordProfile";
import TenantList from "./Components/LandLoard/Tenant/TenantList";
import TenantDetails from "./Components/LandLoard/Tenant/TenantDetails";
import RoomAdd from "./Components/LandLoard/Property/RoomAdd";
import Layout from "./Components/LandLoard/Layout/Layout";

function App() {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* 🌐 Public Website with Navbar/Footer */}
          <Route
            path="*"
            element={
              <div className="flex flex-col min-h-screen">
                <Navbar />
                <div className="flex-grow pt-20">
                  <Routes>
                    <Route index element={<MainPage />} />
                    <Route path="/properties" element={<AllProperty />} />
                    <Route path="/property/:id" element={<PropertyDetails />} />
                    <Route path="/pg" element={<PG />} />
                    <Route path="/pg/:id" element={<PgDetails />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/hostel" element={<Hostel />} />
                    <Route path="/hostel/:id" element={<HostelDetail />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/rent" element={<RentProperty />} />
                    <Route path="/rent/:id" element={<RentPropertyDetail />} />
                    <Route path="/sell" element={<SellProperty />} />
                    <Route path="/sell/:id" element={<SellPropertyDetail />} />
                    <Route path="/hotel" element={<Hotel_Banqute />} />
                    <Route path="/hotel/:id" element={<Hotel_BanquteDetails />} />
                  </Routes>
                </div>
                <Footer />
              </div>
            }
          />

          {/* 👤 User Section (My Profile & Bookings) */}
          <Route path="/user" element={<UserLayout />}>
            <Route path="profile" element={<ProfilePage />} />
            <Route path="bookings" element={<BookingsPage />} />
          </Route>

          {/* 🏠 Landlord Dashboard Section */}
          <Route path="/landlord/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="landlord-profile" element={<LandlordProfile />} />
            <Route path="property-list" element={<PropertyList />} />
            <Route path="add-property" element={<AddProperty />} />
            <Route path="room-overview" element={<RoomOverview />} />
            <Route path="add-room" element={<RoomAdd />} />
            <Route path="property" element={<Property />} />
            <Route path="property/:id" element={<PropertyDetail />} />
            <Route path="tenants" element={<Tenants />} />
            <Route path="tenant-form" element={<TenantForm />} />
            <Route path="tenant-list" element={<TenantList />} />
            <Route path="tenant-details" element={<TenantDetails />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
